#!/usr/bin/env bash
# Usage: ./apply.sh YOUR_GITHUB_USERNAME
# Run from the folder where you unzipped this overlay, with the Echo-Music clone next to it.
set -e
USER_NAME="${1:?Usage: ./apply.sh YOUR_GITHUB_USERNAME}"
SRC="$(cd "$(dirname "$0")" && pwd)"
TARGET="${2:-../MS-Music}"
[ -d "$TARGET" ] || { echo "Clone upstream first: see steps"; exit 1; }
# 1) remove files that were deleted
while read -r f; do rm -f "$TARGET/$f"; done < "$SRC/deleted.txt"
# 2) copy changed + new files over
(cd "$SRC" && find . -type f ! -name apply.sh ! -name deleted.txt -print0 | xargs -0 -I{} cp --parents "{}" "$TARGET/")
# 3) set your GitHub username in the updater/links
grep -rl "__GITHUB_USER__" "$TARGET/app/src" | xargs -r sed -i "s#__GITHUB_USER__#${USER_NAME}#g"
echo "Done. MS Music files are in $TARGET"

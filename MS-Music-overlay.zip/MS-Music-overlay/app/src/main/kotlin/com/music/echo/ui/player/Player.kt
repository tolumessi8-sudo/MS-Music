package echo.music.iad1tya.ui.player

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.edit
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.Player.STATE_ENDED
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.navigation.NavController
import androidx.palette.graphics.Palette
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.size.Size as CoilSize
import coil3.toBitmap
import com.music.echo.ui.component.BitPerfectBadge
import com.music.innertube.models.PODCAST_BROWSE_PREFIX
import com.music.innertube.models.WatchEndpoint.WatchEndpointMusicSupportedConfigs.WatchEndpointMusicConfig.Companion.MUSIC_VIDEO_TYPE_PODCAST_EPISODE
import dagger.hilt.android.EntryPointAccessors
import echo.music.iad1tya.LocalDatabase
import echo.music.iad1tya.LocalDownloadUtil
import echo.music.iad1tya.LocalListenTogetherManager
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.applecanvas.AppleMusicCanvasProvider
import echo.music.iad1tya.canvas.CanvasArtwork
import echo.music.iad1tya.canvas.TidalCanvasProvider
import echo.music.iad1tya.constants.AudioQuality
import echo.music.iad1tya.constants.AudioQualityKey
import echo.music.iad1tya.constants.CanvasThumbnailAnimationKey
import echo.music.iad1tya.constants.CropAlbumArtKey
import echo.music.iad1tya.constants.DarkModeKey
import echo.music.iad1tya.constants.DislikedSongsKey
import echo.music.iad1tya.constants.EnableLyricsThumbnailPlayPauseKey
import echo.music.iad1tya.constants.HidePlayerThumbnailKey
import echo.music.iad1tya.constants.HideStatusBarOnFullscreenKey
import echo.music.iad1tya.constants.KeepScreenOn
import echo.music.iad1tya.constants.MusicFlowEnabledKey
import echo.music.iad1tya.constants.PlayerBackgroundStyle
import echo.music.iad1tya.constants.PlayerBackgroundStyleKey
import echo.music.iad1tya.constants.PlayerButtonsStyle
import echo.music.iad1tya.constants.PlayerButtonsStyleKey
import echo.music.iad1tya.constants.PlayerHorizontalPadding
import echo.music.iad1tya.constants.QueuePeekHeight
import echo.music.iad1tya.constants.ShowLyricsOnPlayerKey
import echo.music.iad1tya.constants.SliderStyle
import echo.music.iad1tya.constants.SliderStyleKey
import echo.music.iad1tya.constants.SquigglySliderKey
import echo.music.iad1tya.constants.SwipeLyricsKey
import echo.music.iad1tya.constants.ThumbnailCornerRadius
import echo.music.iad1tya.constants.UseNewPlayerDesignKey
import echo.music.iad1tya.constants.WavyPlayPauseKey
import echo.music.iad1tya.db.entities.LyricsEntity
import echo.music.iad1tya.echomusic.getConnectedBluetoothDeviceName
import echo.music.iad1tya.echomusic.isBuds
import echo.music.iad1tya.echomusic.isSpeaker
import echo.music.iad1tya.echomusiccanvas.echomusicCanvasProvider
import echo.music.iad1tya.extensions.SwipeGesture
import echo.music.iad1tya.extensions.togglePlayPause
import echo.music.iad1tya.models.MediaMetadata
import echo.music.iad1tya.playback.ExoDownloadService
import echo.music.iad1tya.playback.audio.bluetooth.BluetoothAudioTracker
import echo.music.iad1tya.ui.component.BottomSheet
import echo.music.iad1tya.ui.component.BottomSheetState
import echo.music.iad1tya.ui.component.HeartBurstIcon
import echo.music.iad1tya.ui.component.Icon as MIcon
import echo.music.iad1tya.ui.component.LocalBottomSheetPageState
import echo.music.iad1tya.ui.component.LocalMenuState
import echo.music.iad1tya.ui.component.Lyrics
import echo.music.iad1tya.ui.component.PlayerSliderTrack
import echo.music.iad1tya.ui.component.ResizableIconButton
import echo.music.iad1tya.ui.component.SquigglySlider
import echo.music.iad1tya.ui.component.WavySlider
import echo.music.iad1tya.ui.component.rememberBottomSheetState
import echo.music.iad1tya.ui.menu.OldPlayerMenu
import echo.music.iad1tya.ui.menu.PlayerMenu
import echo.music.iad1tya.ui.screens.settings.DarkMode
import echo.music.iad1tya.ui.theme.PlayerColorExtractor
import echo.music.iad1tya.ui.theme.PlayerSliderColors
import echo.music.iad1tya.ui.utils.ShowMediaInfo
import echo.music.iad1tya.ui.utils.ShowOffsetDialog
import echo.music.iad1tya.utils.PodcastProgress
import echo.music.iad1tya.utils.dataStore
import echo.music.iad1tya.utils.isLocalMediaId
import echo.music.iad1tya.utils.makeTimeString
import echo.music.iad1tya.utils.rememberEnumPreference
import echo.music.iad1tya.utils.rememberPreference
import echo.music.usbaudio.DacDeviceState
import java.io.File
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

private data class WavyShape(val sides: Int, val indent: Float, val rotationDegrees: Float) :
  Shape {
  override fun createOutline(
    size: Size,
    layoutDirection: LayoutDirection,
    density: Density,
  ): Outline {
    val path = Path()
    val maxRadiusX = size.width / 2f
    val maxRadiusY = size.height / 2f
    val cx = size.width / 2f
    val cy = size.height / 2f

    val steps = 120
    val rotationRad = rotationDegrees * Math.PI / 180.0
    for (i in 0..steps) {
      val angle = i * Math.PI * 2 / steps
      val bumpAngle = angle - rotationRad
      val r = 1f - indent + indent * cos(sides * bumpAngle)
      val x = cx + maxRadiusX * r * cos(angle)
      val y = cy + maxRadiusY * r * sin(angle)
      if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
    }
    path.close()
    return Outline.Generic(path)
  }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun BottomSheetPlayer(
  state: BottomSheetState,
  navController: NavController,
  modifier: Modifier = Modifier,
  pureBlack: Boolean,
  expandQueueRequested: Boolean = false,
  onQueueExpanded: () -> Unit = {},
  showPlayerMenuRequested: Boolean = false,
  onPlayerMenuShown: () -> Unit = {},
  showLyricsRequested: Boolean = false,
  onLyricsShown: () -> Unit = {},
) {
  val context = LocalContext.current
  val database = LocalDatabase.current
  val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val menuState = LocalMenuState.current
  val bottomSheetPageState = LocalBottomSheetPageState.current
  val playerConnection = LocalPlayerConnection.current ?: return

  val (useNewPlayerDesign, onUseNewPlayerDesignChange) =
    rememberPreference(UseNewPlayerDesignKey, defaultValue = true)
  val (musicFlowEnabled) = rememberPreference(MusicFlowEnabledKey, defaultValue = true)
  val showCodecOnPlayer by
    rememberPreference(echo.music.iad1tya.constants.ShowCodecOnPlayerKey, false)
  val hidePlayerSlider by
    rememberPreference(echo.music.iad1tya.constants.HidePlayerSliderKey, false)
  val (hidePlayerThumbnail, onHidePlayerThumbnailChange) =
    rememberPreference(HidePlayerThumbnailKey, false)
  val showSeekButtons by rememberPreference(echo.music.iad1tya.constants.ShowSeekButtonsKey, false)
  val cropAlbumArt by rememberPreference(CropAlbumArtKey, false)
  val showLyricsOnPlayer by rememberPreference(ShowLyricsOnPlayerKey, false)
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
  val isEpisode =
    mediaMetadata?.let { metadata ->
      val durationMs = maxOf(playerConnection.player.duration, metadata.duration * 1000L)
      PodcastProgress.get(metadata.id) != null ||
        PodcastProgress.isEpisode(metadata, durationMs) ||
        metadata.musicVideoType == MUSIC_VIDEO_TYPE_PODCAST_EPISODE ||
        metadata.artists.any { it.id?.startsWith(PODCAST_BROWSE_PREFIX) == true }
    } == true
  val isLocalMedia = mediaMetadata?.id?.isLocalMediaId() == true

  val playerBackgroundPref by
    rememberEnumPreference(
      key = PlayerBackgroundStyleKey,
      defaultValue = PlayerBackgroundStyle.LIVE_MESH,
    )
  val playerBackground = playerBackgroundPref
  val playerButtonsStyle by
    rememberEnumPreference(key = PlayerButtonsStyleKey, defaultValue = PlayerButtonsStyle.TERTIARY)

  val isSystemInDarkTheme = isSystemInDarkTheme()
  val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
  val useDarkTheme =
    remember(darkTheme, isSystemInDarkTheme) {
      if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
    }

  val dataSaverEnabled by
    rememberPreference(key = echo.music.iad1tya.constants.DataSaverEnabledKey, defaultValue = false)
  val enableCanvasPref by rememberPreference(CanvasThumbnailAnimationKey, defaultValue = false)
  val enableCanvas = if (dataSaverEnabled) false else enableCanvasPref

  val shouldUseDarkButtonColors =
    remember(playerBackground, useDarkTheme) {
      when (playerBackground) {
        PlayerBackgroundStyle.BLUR,
        PlayerBackgroundStyle.GRADIENT,
        PlayerBackgroundStyle.GLOW_ANIMATED,
        PlayerBackgroundStyle.APPLE_MUSIC,
        PlayerBackgroundStyle.LIVE_MESH,
        PlayerBackgroundStyle.LIQUID_GLASS -> true
        PlayerBackgroundStyle.DEFAULT -> useDarkTheme
      }
    }
  val isPlaying by playerConnection.isPlaying.collectAsState()
  val isCrossfading by playerConnection.isCrossfading.collectAsState()
  val isAutomixing by playerConnection.isAutomixing.collectAsState()
  val automixDebug by playerConnection.automixDebugInfo.collectAsState()
  val automixDebugOverlayEnabled by
    rememberPreference(echo.music.iad1tya.constants.AutomixDebugOverlayKey, false)

  var currentAudioFormat by remember { mutableStateOf<androidx.media3.common.Format?>(null) }
  DisposableEffect(playerConnection, isCrossfading) {
    val playerToListen = playerConnection.player
    val listener =
      object : Player.Listener {
        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
          val audioTrack = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO }
          currentAudioFormat = audioTrack?.getTrackFormat(0)
        }
      }
    playerToListen.addListener(listener)
    currentAudioFormat =
      playerToListen.currentTracks.groups
        .firstOrNull { it.type == C.TRACK_TYPE_AUDIO }
        ?.getTrackFormat(0)
    onDispose { playerToListen.removeListener(listener) }
  }
  val swipeLyrics by rememberPreference(SwipeLyricsKey, false)
  val enableLyricsThumbnailPlayPause by rememberPreference(EnableLyricsThumbnailPlayPauseKey, false)
  val isKeepScreenOn by rememberPreference(KeepScreenOn, false)
  val keepScreenOn = isPlaying && isKeepScreenOn

  var isTopLight by remember(mediaMetadata?.id) { mutableStateOf(false) }

  LaunchedEffect(mediaMetadata?.id, playerBackground, useDarkTheme) {
    val currentMetadata = mediaMetadata
    if (playerBackground == PlayerBackgroundStyle.DEFAULT) {
      isTopLight = !useDarkTheme
      return@LaunchedEffect
    }
    if (currentMetadata == null || currentMetadata.thumbnailUrl == null) {
      isTopLight = false
      return@LaunchedEffect
    }

    withContext(Dispatchers.IO) {
      val request =
        ImageRequest.Builder(context)
          .data(currentMetadata.thumbnailUrl)
          .size(100, 100)
          .allowHardware(false)
          .build()

      val result = runCatching { context.imageLoader.execute(request) }.getOrNull()
      val bitmap = result?.image?.toBitmap()
      if (bitmap != null) {
        val w = bitmap.width
        val h = (bitmap.height * 0.22f).toInt().coerceIn(1, bitmap.height)
        var totalLum = 0.0
        var count = 0
        for (x in 0 until w step maxOf(1, w / 10)) {
          for (y in 0 until h step maxOf(1, h / 5)) {
            val pixel = bitmap.getPixel(x, y)
            val r = android.graphics.Color.red(pixel) / 255.0
            val g = android.graphics.Color.green(pixel) / 255.0
            val b = android.graphics.Color.blue(pixel) / 255.0
            totalLum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
          }
        }
        val avgLum = if (count > 0) totalLum / count else 0.0
        withContext(Dispatchers.Main) {
          isTopLight = avgLum > 0.55
        }
      } else {
        withContext(Dispatchers.Main) {
          isTopLight = false
        }
      }
    }
  }

  DisposableEffect(
    playerBackground,
    state.isExpanded,
    useDarkTheme,
    keepScreenOn,
    mediaMetadata?.id,
    isTopLight,
  ) {
    val window = (context as? android.app.Activity)?.window
    if (window != null && state.isExpanded) {
      val insetsController = WindowCompat.getInsetsController(window, window.decorView)

      val isLocal = mediaMetadata?.id?.isLocalMediaId() == true
      if (
        isLocal ||
          playerBackground in
            listOf(
              PlayerBackgroundStyle.BLUR,
              PlayerBackgroundStyle.GRADIENT,
              PlayerBackgroundStyle.GLOW_ANIMATED,
              PlayerBackgroundStyle.APPLE_MUSIC,
              PlayerBackgroundStyle.LIVE_MESH,
            )
      ) {
        insetsController.isAppearanceLightStatusBars = isTopLight
      } else {
        insetsController.isAppearanceLightStatusBars = !useDarkTheme
      }

      if (keepScreenOn && state.isExpanded)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    onDispose {
      if (window != null) {
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.isAppearanceLightStatusBars = !useDarkTheme
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      }
    }
  }
  val onBackgroundColor =
    when (playerBackground) {
      PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.secondary
      else -> MaterialTheme.colorScheme.onSurface
    }
  val useBlackBackground =
    remember(isSystemInDarkTheme, darkTheme, pureBlack) {
      val useDarkTheme =
        if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
      useDarkTheme && pureBlack
    }

  val playbackState by playerConnection.playbackState.collectAsState()
  val currentFormatEntity by database.format(mediaMetadata?.id).collectAsState(initial = null)
  val currentSong by playerConnection.currentSong.collectAsState(initial = null)
  val automix by playerConnection.service.automixItems.collectAsState()
  val repeatMode by playerConnection.repeatMode.collectAsState()
  val canSkipPrevious by playerConnection.canSkipPrevious.collectAsState()
  val canSkipNext by playerConnection.canSkipNext.collectAsState()
  val isMuted by playerConnection.isMuted.collectAsState()
  val playerVolume by playerConnection.service.playerVolume.collectAsState()

  val (audioQuality) = rememberEnumPreference(AudioQualityKey, defaultValue = AudioQuality.OPUS)
  val sliderStyle by rememberEnumPreference(SliderStyleKey, SliderStyle.WAVY)
  val squigglySlider by rememberPreference(SquigglySliderKey, defaultValue = false)
  val wavyPlayPause by rememberPreference(WavyPlayPauseKey, defaultValue = true)

  val listenTogetherManager = LocalListenTogetherManager.current
  val isListenTogetherGuest by
    listenTogetherManager?.guestPlaybackRestricted?.collectAsState(initial = false)
      ?: remember { mutableStateOf(false) }

  val castHandler =
    remember(playerConnection) {
      try {
        playerConnection.service.castConnectionHandler
      } catch (e: Exception) {
        null
      }
    }
  val isCasting by castHandler?.isCasting?.collectAsState() ?: remember { mutableStateOf(false) }
  val castDeviceName by
    castHandler?.castDeviceName?.collectAsState() ?: remember { mutableStateOf(null) }
  val castPosition by
    castHandler?.castPosition?.collectAsState() ?: remember { mutableLongStateOf(0L) }
  val castDuration by
    castHandler?.castDuration?.collectAsState() ?: remember { mutableLongStateOf(0L) }
  val castIsPlaying by
    castHandler?.castIsPlaying?.collectAsState() ?: remember { mutableStateOf(false) }
  val castVolume by
    castHandler?.castVolume?.collectAsState() ?: remember { mutableFloatStateOf(1f) }

  val effectiveIsPlaying = if (isCasting) castIsPlaying else isPlaying

  val positionState = remember { mutableLongStateOf(0L) }
  val durationState = remember { mutableLongStateOf(0L) }

  var position by positionState
  var duration by durationState

  val effectivePosition by remember {
    derivedStateOf {
      if (isCasting) {
        castPosition
      } else {
        position
      }
    }
  }

  var sliderPosition by remember { mutableStateOf<Long?>(null) }

  val automixDebugOverlay: @Composable () -> Unit = {
    if (automixDebugOverlayEnabled) {
      automixDebug?.let { dbg ->
        val mono =
          MaterialTheme.typography.labelSmall.copy(
            fontSize = 9.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
          )
        Column(
          modifier =
            Modifier.padding(horizontal = PlayerHorizontalPadding, vertical = 4.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(Color.Black.copy(alpha = 0.45f))
              .padding(6.dp)
        ) {
          Text("AUTOMIX  ${dbg.status}", style = mono, color = Color.White)
          Text(
            "out: ${dbg.outBpm?.let { "%.1f bpm".format(it) } ?: "—"}" +
              (dbg.outConfidence?.let { "  conf %.2f".format(it) } ?: "") +
              (dbg.outMixOutMs?.takeIf { it > 0 }?.let { "  mixOut ${makeTimeString(it)}" } ?: ""),
            style = mono,
            color = Color.White.copy(alpha = 0.85f),
          )
          Text(
            "in:  ${dbg.inBpm?.let { "%.1f bpm".format(it) } ?: "—"}" +
              (dbg.inConfidence?.let { "  conf %.2f".format(it) } ?: "") +
              (dbg.inMixInMs?.takeIf { it > 0 }?.let { "  mixIn ${makeTimeString(it)}" } ?: ""),
            style = mono,
            color = Color.White.copy(alpha = 0.85f),
          )
          if (dbg.triggerTimeMs != null) {
            val remainingS =
              ((dbg.triggerTimeMs - (sliderPosition ?: effectivePosition)) / 1000).coerceAtLeast(0)
            Text(
              "mix @ ${makeTimeString(dbg.triggerTimeMs)} (in ${remainingS}s)" +
                (dbg.incomingStartMs?.let { "  from ${makeTimeString(it)}" } ?: "") +
                (dbg.tempoRatio?.let { "  ×%.3f".format(it) } ?: ""),
              style = mono,
              color = Color.White.copy(alpha = 0.85f),
            )
          }
        }
      }
    }
  }

  var lastManualSeekTime by remember { mutableLongStateOf(0L) }

  var gradientColors by remember { mutableStateOf<List<Color>>(emptyList()) }
  val gradientColorsCache = remember { mutableMapOf<String, List<Color>>() }

  if (!canSkipNext && automix.isNotEmpty()) {
    playerConnection.service.addToQueueAutomix(automix[0], 0)
  }

  val bluetoothTracker = remember(context) { BluetoothAudioTracker(context) }
  DisposableEffect(bluetoothTracker) {
    bluetoothTracker.start()
    onDispose { bluetoothTracker.stop() }
  }
  val bluetoothTelemetry by bluetoothTracker.telemetry.collectAsState()

  val dacDeviceState by (playerConnection.service.usbDacManager.activeDacFlow).collectAsState()

  val bluetoothDeviceName by
    produceState<String?>(initialValue = getConnectedBluetoothDeviceName(context)) {
      val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

      val receiver =
        object : BroadcastReceiver() {
          override fun onReceive(context: Context, intent: Intent) {
            value = getConnectedBluetoothDeviceName(context)
          }
        }

      val callback =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesAdded(
              addedDevices: Array<out android.media.AudioDeviceInfo>?
            ) {
              value = getConnectedBluetoothDeviceName(context)
            }

            override fun onAudioDevicesRemoved(
              removedDevices: Array<out android.media.AudioDeviceInfo>?
            ) {
              value = getConnectedBluetoothDeviceName(context)
            }
          }
        } else null

      val filter =
        IntentFilter().apply {
          addAction(AudioManager.ACTION_HEADSET_PLUG)
          addAction("android.bluetooth.adapter.action.STATE_CHANGED")
          addAction("android.bluetooth.device.action.ACL_CONNECTED")
          addAction("android.bluetooth.device.action.ACL_DISCONNECTED")
          addAction("android.media.AUDIO_BECOMING_NOISY")
        }

      context.registerReceiver(receiver, filter)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && callback != null) {
        audioManager.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
      }

      awaitDispose {
        context.unregisterReceiver(receiver)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && callback != null) {
          audioManager.unregisterAudioDeviceCallback(callback)
        }
      }
    }

  val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
  val maxSystemVolume = remember {
    audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
  }
  val systemVolume by
    produceState(
      initialValue =
        audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxSystemVolume
    ) {
      val receiver =
        object : BroadcastReceiver() {
          override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == "android.media.VOLUME_CHANGED_ACTION") {
              value =
                audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxSystemVolume
            }
          }
        }
      val filter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
      context.registerReceiver(receiver, filter)
      awaitDispose { context.unregisterReceiver(receiver) }
    }

  val defaultGradientColors =
    listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant)
  val fallbackColor = MaterialTheme.colorScheme.surface.toArgb()

  LaunchedEffect(mediaMetadata?.id, playerBackground) {
    if (
      playerBackground == PlayerBackgroundStyle.GRADIENT ||
        playerBackground == PlayerBackgroundStyle.GLOW_ANIMATED
    ) {
      val currentMetadata = mediaMetadata
      if (currentMetadata != null && currentMetadata.thumbnailUrl != null) {
        val cachedColors = gradientColorsCache[currentMetadata.id]
        if (cachedColors != null) {
          gradientColors = cachedColors
          return@LaunchedEffect
        }
        withContext(Dispatchers.IO) {
          val request =
            ImageRequest.Builder(context)
              .data(currentMetadata.thumbnailUrl)
              .size(100, 100)
              .allowHardware(false)
              .memoryCacheKey("gradient_${currentMetadata.id}")
              .build()

          val result = runCatching { context.imageLoader.execute(request) }.getOrNull()
          if (result != null) {
            val bitmap = result.image?.toBitmap()
            if (bitmap != null) {
              val palette =
                withContext(Dispatchers.Default) {
                  Palette.from(bitmap).maximumColorCount(8).resizeBitmapArea(100 * 100).generate()
                }
              val extractedColors =
                if (playerBackground == PlayerBackgroundStyle.GLOW_ANIMATED) {
                  listOfNotNull(
                      palette.getVibrantColor(fallbackColor).let { Color(it) },
                      palette.getLightVibrantColor(fallbackColor).let { Color(it) },
                      palette.getDarkVibrantColor(fallbackColor).let { Color(it) },
                      palette.getMutedColor(fallbackColor).let { Color(it) },
                      palette.getLightMutedColor(fallbackColor).let { Color(it) },
                      palette.getDarkMutedColor(fallbackColor).let { Color(it) },
                    )
                    .distinct()
                } else {
                  PlayerColorExtractor.extractGradientColors(
                    palette = palette,
                    fallbackColor = fallbackColor,
                  )
                }
              gradientColorsCache[currentMetadata.id] = extractedColors
              withContext(Dispatchers.Main) { gradientColors = extractedColors }
            }
          }
        }
      }
    } else {
      gradientColors = emptyList()
    }
  }

  val TextBackgroundColor by
    animateColorAsState(
      targetValue =
        when {
          isLocalMedia -> Color.White
          playerBackground == PlayerBackgroundStyle.DEFAULT ->
            MaterialTheme.colorScheme.onBackground
          else -> Color.White
        },
      label = "TextBackgroundColor",
    )

  val icBackgroundColor by
    animateColorAsState(
      targetValue =
        when {
          isLocalMedia -> Color.Black
          playerBackground == PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.surface
          else -> Color.Black
        },
      label = "icBackgroundColor",
    )

  var canvasArtwork by remember(mediaMetadata?.id) { mutableStateOf<CanvasArtwork?>(null) }
  var canvasFetchInFlight by remember(mediaMetadata?.id) { mutableStateOf(false) }

  LaunchedEffect(mediaMetadata?.id, playerBackground, enableCanvas) {
    if (playerBackground != PlayerBackgroundStyle.APPLE_MUSIC || !enableCanvas) {
      canvasArtwork = null
      return@LaunchedEffect
    }
    val item = mediaMetadata ?: return@LaunchedEffect

    CanvasArtworkPlaybackCache.get(item.id)?.let { cached ->
      canvasArtwork = cached
      return@LaunchedEffect
    }

    try {
      val file = File(context.filesDir, "canvas_${item.id}.json")
      if (file.exists()) {
        val cached = Json.decodeFromString<echo.music.iad1tya.canvas.CanvasArtwork>(file.readText())
        if (cached.isYouTubeSnippet) {
          file.delete()
        } else {
          CanvasArtworkPlaybackCache.put(item.id, cached)
          canvasArtwork = cached
          return@LaunchedEffect
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    if (canvasFetchInFlight) return@LaunchedEffect
    canvasFetchInFlight = true
    try {
      val playerDurationSec =
        try {
          playerConnection.player.duration.takeIf { it > 0 }?.div(1000L)
        } catch (e: Exception) {
          null
        }

      withContext(Dispatchers.IO) {
        val storefront =
          Locale.getDefault().country.lowercase(Locale.ROOT).takeIf { it.length == 2 } ?: "us"
        val requestedTitle = item.title
        val requestedArtist = item.artists.joinToString { it.name }
        val requestedAlbum = item.album?.title ?: ""

        val s = normalizeCanvasSongTitle(requestedTitle)
        val a = normalizeCanvasArtistName(requestedArtist)

        val fetched =
          echomusicCanvasProvider.getBySongArtist(s, a)?.takeIf {
            !it.preferredAnimationUrl.isNullOrBlank()
          }
            ?: TidalCanvasProvider.getBySongArtist(s, a, requestedAlbum)?.takeIf {
              !it.preferredAnimationUrl.isNullOrBlank()
            }
            ?: AppleMusicCanvasProvider.getBySongArtist(s, a, requestedAlbum, storefront)?.takeIf {
              !it.preferredAnimationUrl.isNullOrBlank()
            }

        val validated =
          fetched
            ?.takeIf { !it.isYouTubeSnippet }
            ?.let { artwork ->
              val localArtists = splitAndNormalizeArtists(requestedArtist)
              val returnedArtists = splitAndNormalizeArtists(artwork.artist ?: "")
              val artistMatches =
                localArtists.isNotEmpty() &&
                  returnedArtists.isNotEmpty() &&
                  (localArtists.any { local ->
                    returnedArtists.any { it.equals(local, ignoreCase = true) }
                  })

              if (artistMatches) artwork else null
            }

        withContext(Dispatchers.Main) {
          canvasArtwork = validated
          if (validated != null) {
            CanvasArtworkPlaybackCache.put(item.id, validated)
          }
        }
      }
    } finally {
      canvasFetchInFlight = false
    }
  }

  val (textButtonColor, iconButtonColor) =
    when {
      isLocalMedia ||
        playerBackground == PlayerBackgroundStyle.BLUR ||
        playerBackground == PlayerBackgroundStyle.GRADIENT ||
        playerBackground == PlayerBackgroundStyle.GLOW_ANIMATED ||
        playerBackground == PlayerBackgroundStyle.APPLE_MUSIC ||
        playerBackground == PlayerBackgroundStyle.LIVE_MESH ||
        playerBackground == PlayerBackgroundStyle.LIQUID_GLASS -> {
        when (playerButtonsStyle) {
          PlayerButtonsStyle.DEFAULT -> Pair(Color.White, Color.Black)
          PlayerButtonsStyle.PRIMARY ->
            Pair(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
          PlayerButtonsStyle.TERTIARY ->
            Pair(MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.onTertiary)
        }
      }
      else -> {
        when (playerButtonsStyle) {
          PlayerButtonsStyle.DEFAULT ->
            if (useDarkTheme) Pair(Color.White, Color.Black) else Pair(Color.Black, Color.White)
          PlayerButtonsStyle.PRIMARY ->
            Pair(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
          PlayerButtonsStyle.TERTIARY ->
            Pair(MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.onTertiary)
        }
      }
    }

  val (sideButtonContainerColor, sideButtonContentColor) =
    when (playerButtonsStyle) {
      PlayerButtonsStyle.DEFAULT -> Pair(Color.White.copy(alpha = 0.2f), Color.White)
      PlayerButtonsStyle.PRIMARY ->
        Pair(
          MaterialTheme.colorScheme.primaryContainer,
          MaterialTheme.colorScheme.onPrimaryContainer,
        )
      PlayerButtonsStyle.TERTIARY ->
        Pair(
          MaterialTheme.colorScheme.tertiaryContainer,
          MaterialTheme.colorScheme.onTertiaryContainer,
        )
    }

  val download by
    LocalDownloadUtil.current.getDownload(mediaMetadata?.id ?: "").collectAsState(initial = null)

  val sleepTimerEnabled =
    remember(
      playerConnection.service.sleepTimer.triggerTime,
      playerConnection.service.sleepTimer.pauseWhenSongEnd,
    ) {
      playerConnection.service.sleepTimer.isActive
    }

  var sleepTimerTimeLeft by remember { mutableLongStateOf(0L) }

  LaunchedEffect(sleepTimerEnabled) {
    if (sleepTimerEnabled) {
      while (isActive) {
        sleepTimerTimeLeft =
          if (playerConnection.service.sleepTimer.pauseWhenSongEnd) {
            playerConnection.player.duration - playerConnection.player.currentPosition
          } else {
            playerConnection.service.sleepTimer.triggerTime - System.currentTimeMillis()
          }
        delay(1000L)
      }
    }
  }

  var showSleepTimerDialog by remember { mutableStateOf(false) }

  var sleepTimerValue by remember { mutableFloatStateOf(30f) }
  if (showSleepTimerDialog) {
    AlertDialog(
      properties = DialogProperties(usePlatformDefaultWidth = false),
      onDismissRequest = { showSleepTimerDialog = false },
      icon = { Icon(painter = painterResource(R.drawable.bedtime), contentDescription = null) },
      title = { Text(stringResource(R.string.sleep_timer)) },
      confirmButton = {
        TextButton(
          onClick = {
            showSleepTimerDialog = false
            playerConnection.service.sleepTimer.start(sleepTimerValue.roundToInt())
          }
        ) {
          Text(stringResource(android.R.string.ok))
        }
      },
      dismissButton = {
        TextButton(onClick = { showSleepTimerDialog = false }) {
          Text(stringResource(android.R.string.cancel))
        }
      },
      text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text =
              pluralStringResource(
                R.plurals.minute,
                sleepTimerValue.roundToInt(),
                sleepTimerValue.roundToInt(),
              ),
            style = MaterialTheme.typography.bodyLarge,
          )

          Slider(
            value = sleepTimerValue,
            onValueChange = { sleepTimerValue = it },
            valueRange = 5f..120f,
            steps = (120 - 5) / 5 - 1,
          )

          OutlinedIconButton(
            onClick = {
              showSleepTimerDialog = false
              playerConnection.service.sleepTimer.start(-1)
            }
          ) {
            Text(stringResource(R.string.end_of_song))
          }
        }
      },
    )
  }

  var showChoosePlaylistDialog by rememberSaveable { mutableStateOf(false) }

  var showInlineLyrics by rememberSaveable { mutableStateOf(false) }

  var isFullScreen by rememberSaveable { mutableStateOf(false) }

  val hideStatusBarOnFullscreen by
    rememberPreference(HideStatusBarOnFullscreenKey, defaultValue = false)

  DisposableEffect(isFullScreen, hideStatusBarOnFullscreen) {
    val window = (context as? android.app.Activity)?.window
    if (window != null) {
      val insetsController = WindowCompat.getInsetsController(window, window.decorView)
      if (isFullScreen && hideStatusBarOnFullscreen) {
        insetsController.hide(WindowInsetsCompat.Type.statusBars())
        insetsController.systemBarsBehavior =
          WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
      } else {
        insetsController.show(WindowInsetsCompat.Type.statusBars())
      }
    }

    onDispose {
      if (window != null) {
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.statusBars())
      }
    }
  }

  LaunchedEffect(isPlaying, isCasting) {
    if (!isCasting && isPlaying) {
      while (isActive) {
        delay(200)
        if (sliderPosition == null) {
          position = playerConnection.player.currentPosition
          duration =
            echo.music.iad1tya.playback.PlaybackCutoffGuard.computeEffectiveDuration(
              mediaMetadata?.duration,
              playerConnection.player.duration,
            )
        }
      }
    }
  }

  LaunchedEffect(playbackState, mediaMetadata?.id) {
    if (!isCasting) {
      position = playerConnection.player.currentPosition
      duration =
        echo.music.iad1tya.playback.PlaybackCutoffGuard.computeEffectiveDuration(
          mediaMetadata?.duration,
          playerConnection.player.duration,
        )
    }
  }

  LaunchedEffect(isCasting, castPosition, castDuration) {
    if (isCasting && sliderPosition == null) {
      val timeSinceManualSeek = System.currentTimeMillis() - lastManualSeekTime
      if (timeSinceManualSeek > 1500) {

        position = castPosition
        if (castDuration > 0) duration = castDuration
      }
    }
  }

  val dismissedBound =
    QueuePeekHeight + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()

  val queueSheetState =
    rememberBottomSheetState(
      dismissedBound = dismissedBound,
      expandedBound = state.expandedBound,
      collapsedBound = dismissedBound + 1.dp,
      initialAnchor = 1,
    )

  LaunchedEffect(expandQueueRequested) {
    if (expandQueueRequested) {
      state.expandSoft()
      queueSheetState.expandSoft()
      onQueueExpanded()
    }
  }

  LaunchedEffect(showPlayerMenuRequested, mediaMetadata) {
    if (showPlayerMenuRequested && mediaMetadata != null) {
      state.expandSoft()
      menuState.show {
        PlayerMenu(
          mediaMetadata = mediaMetadata!!,
          navController = navController,
          playerBottomSheetState = state,
          onShowDetailsDialog = {
            mediaMetadata?.id?.let { id ->
              bottomSheetPageState.show { ShowMediaInfo(id) }
            }
          },
          onDismiss = menuState::dismiss,
        )
      }
      onPlayerMenuShown()
    }
  }

  LaunchedEffect(showLyricsRequested) {
    if (showLyricsRequested) {
      state.expandSoft()
      showInlineLyrics = true
      onLyricsShown()
    }
  }

  val bottomSheetBackgroundColor =
    when {
      isLocalMedia -> Color.Black
      playerBackground in
        listOf(
          PlayerBackgroundStyle.BLUR,
          PlayerBackgroundStyle.GRADIENT,
          PlayerBackgroundStyle.GLOW_ANIMATED,
          PlayerBackgroundStyle.APPLE_MUSIC,
        ) -> MaterialTheme.colorScheme.surfaceContainer
      playerBackground == PlayerBackgroundStyle.LIVE_MESH ||
        playerBackground == PlayerBackgroundStyle.LIQUID_GLASS -> Color.Black
      else -> if (useBlackBackground) Color.Black else MaterialTheme.colorScheme.surfaceContainer
    }

  val backgroundAlphaProvider = remember(state) { { state.progress.coerceIn(0f, 1f) } }
  val showCanvas by remember(state) { derivedStateOf { backgroundAlphaProvider() > 0.01f } }

  BottomSheet(
    state = state,
    modifier = modifier,
    background = {
      val backgroundThumbnailUrl =
        mediaMetadata?.thumbnailUrl
          ?: playerConnection.player.currentMediaItem?.mediaMetadata?.artworkUri?.toString()
      Box(modifier = Modifier.fillMaxSize().background(bottomSheetBackgroundColor)) {
        when (playerBackground) {
          PlayerBackgroundStyle.BLUR -> {
            AnimatedContent(
              targetState = backgroundThumbnailUrl,
              transitionSpec = { fadeIn(tween(800)).togetherWith(fadeOut(tween(800))) },
              label = "blurBackground",
            ) { thumbnailUrl ->
              if (thumbnailUrl != null) {
                Box(modifier = Modifier.graphicsLayer { alpha = backgroundAlphaProvider() }) {
                  AsyncImage(
                    model =
                      ImageRequest.Builder(context)
                        .data(thumbnailUrl)
                        .size(100, 100)
                        .allowHardware(false)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur(if (useDarkTheme) 150.dp else 100.dp),
                  )
                  Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)))
                }
              }
            }
          }
          PlayerBackgroundStyle.GRADIENT -> {
            AnimatedContent(
              targetState = gradientColors,
              transitionSpec = { fadeIn(tween(800)).togetherWith(fadeOut(tween(800))) },
              label = "gradientBackground",
            ) { colors ->
              if (colors.isNotEmpty()) {
                val gradientColorStops =
                  if (colors.size >= 3) {
                    arrayOf(0.0f to colors[0], 0.5f to colors[1], 1.0f to colors[2])
                  } else {
                    arrayOf(
                      0.0f to colors[0],
                      0.6f to colors[0].copy(alpha = 0.7f),
                      1.0f to Color.Black,
                    )
                  }
                Box(
                  Modifier.fillMaxSize()
                    .graphicsLayer { alpha = backgroundAlphaProvider() }
                    .background(Brush.verticalGradient(colorStops = gradientColorStops))
                    .background(Color.Black.copy(alpha = 0.2f))
                )
              }
            }
          }
          PlayerBackgroundStyle.GLOW_ANIMATED -> {
            AnimatedContent(
              targetState = gradientColors,
              transitionSpec = { fadeIn(tween(1200)) togetherWith fadeOut(tween(1200)) },
              label = "GlowAnimatedContent",
            ) { colors ->
              if (colors.isNotEmpty()) {
                val infiniteTransition = rememberInfiniteTransition(label = "GlowAnimation")

                val progress by
                  infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec =
                      infiniteRepeatable(
                        animation = tween(20000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart,
                      ),
                    label = "glowProgress",
                  )

                fun rotatedColorAt(index: Int): Color {
                  val size = colors.size
                  val idx = index.toFloat() + progress * size
                  val a = kotlin.math.floor(idx).toInt() % size
                  val b = (a + 1) % size
                  val frac = idx - kotlin.math.floor(idx)
                  return androidx.compose.ui.graphics.lerp(
                    colors.getOrElse(a) { Color.DarkGray },
                    colors.getOrElse(b) { Color.DarkGray },
                    frac,
                  )
                }

                fun oscillate(min: Float, max: Float, phase: Float, speed: Float = 1f): Float {
                  val v =
                    kotlin.math.sin(2f * kotlin.math.PI.toFloat() * (progress * speed + phase))
                  return min + (max - min) * ((v + 1f) * 0.5f)
                }

                val color1 = rotatedColorAt(0)
                val color2 = rotatedColorAt(1)
                val color3 = rotatedColorAt(2)
                val color4 = rotatedColorAt(3)
                val color5 = rotatedColorAt(4)
                val color6 = rotatedColorAt(5)

                val o1x = oscillate(0.0f, 1.0f, 0.00f, 1.0f)
                val o1y = oscillate(0.0f, 0.5f, 0.07f, 1.0f)
                val r1 = oscillate(0.8f, 1.6f, 0.12f, 1.0f)

                val o2x = oscillate(1.0f, 0.0f, 0.2f, 1.0f)
                val o2y = oscillate(0.5f, 1.0f, 0.25f, 1.0f)
                val r2 = oscillate(0.7f, 1.5f, 0.18f, 1.0f)

                val o3x = oscillate(0.2f, 0.8f, 0.33f, 1.0f)
                val o3y = oscillate(0.8f, 0.2f, 0.36f, 1.0f)
                val r3 = oscillate(0.6f, 1.4f, 0.29f, 1.0f)

                val o4x = oscillate(0.3f, 0.7f, 0.44f, 1.0f)
                val o4y = oscillate(0.2f, 0.8f, 0.41f, 1.0f)
                val r4 = oscillate(0.9f, 1.7f, 0.47f, 1.0f)

                val o5x = oscillate(0.4f, 0.6f, 0.55f, 1.0f)
                val o5y = oscillate(0.0f, 1.0f, 0.51f, 1.0f)
                val r5 = oscillate(0.7f, 1.5f, 0.58f, 1.0f)

                val o6x = oscillate(0.0f, 1.0f, 0.66f, 1.0f)
                val o6y = oscillate(0.5f, 0.7f, 0.62f, 1.0f)
                val r6 = oscillate(0.8f, 1.8f, 0.69f, 1.0f)

                Box(
                  modifier =
                    Modifier.fillMaxSize()
                      .graphicsLayer { alpha = backgroundAlphaProvider() }
                      .drawWithCache {
                        val width = size.width
                        val height = size.height
                        val baseColor = Color(0xFF050505)

                        val brush1 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color1.copy(alpha = 0.85f),
                                color1.copy(alpha = 0.5f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o1x, height * o1y),
                            radius = width * r1,
                          )
                        val brush2 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color2.copy(alpha = 0.8f),
                                color2.copy(alpha = 0.45f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o2x, height * o2y),
                            radius = width * r2,
                          )
                        val brush3 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color3.copy(alpha = 0.75f),
                                color3.copy(alpha = 0.4f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o3x, height * o3y),
                            radius = width * r3,
                          )
                        val brush4 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color4.copy(alpha = 0.7f),
                                color4.copy(alpha = 0.35f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o4x, height * o4y),
                            radius = width * r4,
                          )
                        val brush5 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color5.copy(alpha = 0.65f),
                                color5.copy(alpha = 0.3f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o5x, height * o5y),
                            radius = width * r5,
                          )
                        val brush6 =
                          Brush.radialGradient(
                            colors =
                              listOf(
                                color6.copy(alpha = 0.6f),
                                color6.copy(alpha = 0.25f),
                                Color.Transparent,
                              ),
                            center = Offset(width * o6x, height * o6y),
                            radius = width * r6,
                          )

                        onDrawBehind {
                          drawRect(color = baseColor)
                          drawRect(brush = brush1)
                          drawRect(brush = brush2)
                          drawRect(brush = brush3)
                          drawRect(brush = brush4)
                          drawRect(brush = brush5)
                          drawRect(brush = brush6)
                        }
                      }
                )
              }
            }
          }
          PlayerBackgroundStyle.APPLE_MUSIC -> {
            AnimatedContent(
              targetState = backgroundThumbnailUrl,
              transitionSpec = { fadeIn(tween(1200)).togetherWith(fadeOut(tween(1200))) },
              label = "appleMusicBackground",
            ) { thumbnailUrl ->
              if (thumbnailUrl != null) {
                Box(
                  modifier =
                    Modifier.fillMaxSize().graphicsLayer { alpha = backgroundAlphaProvider() }
                ) {
                  AsyncImage(
                    model =
                      ImageRequest.Builder(context)
                        .data(thumbnailUrl)
                        .size(128, 128)
                        .allowHardware(false)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur(150.dp),
                  )

                  val clearArtworkAlpha by
                    animateFloatAsState(
                      targetValue = if (showInlineLyrics) 0f else 1f,
                      animationSpec = tween(500),
                      label = "clearArtworkAlpha",
                    )

                  Box(
                    modifier =
                      Modifier.fillMaxWidth()
                        .fillMaxHeight(0.68f)
                        .alpha(clearArtworkAlpha)
                        .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                        .drawWithContent {
                          drawContent()

                          drawRect(
                            brush =
                              Brush.verticalGradient(
                                colorStops =
                                  arrayOf(
                                    0.00f to Color.Black,
                                    0.70f to Color.Black,
                                    0.88f to Color.Black.copy(alpha = 0.4f),
                                    1.00f to Color.Transparent,
                                  )
                              ),
                            blendMode = BlendMode.DstIn,
                          )
                        }
                  ) {
                    AsyncImage(
                      model =
                        ImageRequest.Builder(context)
                          .data(thumbnailUrl)
                          .size(CoilSize.ORIGINAL)
                          .build(),
                      contentDescription = null,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize(),
                    )

                    if (enableCanvas && canvasArtwork != null && showCanvas) {
                      CanvasArtworkPlayer(
                        primaryUrl = canvasArtwork?.animated,
                        fallbackUrl = canvasArtwork?.videoUrl,
                        isPlaying = isPlaying,
                        clipStartMs = canvasArtwork?.clipStartMs,
                        clipEndMs = canvasArtwork?.clipEndMs,
                        modifier = Modifier.fillMaxSize(),
                      )
                    }
                  }

                  Box(
                    modifier =
                      Modifier.fillMaxSize()
                        .background(
                          Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.4f))
                          )
                        )
                  )
                }
              }
            }
          }
          PlayerBackgroundStyle.LIVE_MESH,
          PlayerBackgroundStyle.LIQUID_GLASS -> {
            val infiniteTransition = rememberInfiniteTransition(label = "liveMeshRotation")

            val anchorRotation by
              infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = -360f,
                animationSpec =
                  infiniteRepeatable(
                    animation = tween(80000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart,
                  ),
                label = "anchorRotation",
              )

            val fastRotation by
              infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec =
                  infiniteRepeatable(
                    animation = tween(40000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart,
                  ),
                label = "fastRotation",
              )

            val slowRotation by
              infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec =
                  infiniteRepeatable(
                    animation = tween(60000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart,
                  ),
                label = "slowRotation",
              )

            AnimatedContent(
              targetState = backgroundThumbnailUrl,
              transitionSpec = { fadeIn(tween(1500)).togetherWith(fadeOut(tween(1500))) },
              label = "liveMeshBackground",
            ) { thumbnailUrl ->
              if (thumbnailUrl != null) {
                Box(
                  modifier =
                    Modifier.fillMaxSize()
                      .graphicsLayer { alpha = backgroundAlphaProvider() }
                      .graphicsLayer {
                        scaleX = 1.7f
                        scaleY = 1.7f
                      }
                ) {
                  val matrix = remember {
                    val m = ColorMatrix()
                    m.setToSaturation(1.8f)
                    m
                  }
                  val colorFilter = ColorFilter.colorMatrix(matrix)

                  AsyncImage(
                    model =
                      ImageRequest.Builder(context)
                        .data(thumbnailUrl)
                        .size(128, 128)
                        .allowHardware(false)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    colorFilter = colorFilter,
                    modifier =
                      Modifier.fillMaxSize().blur(100.dp).graphicsLayer {
                        rotationZ = anchorRotation
                      },
                  )

                  AsyncImage(
                    model =
                      ImageRequest.Builder(context)
                        .data(thumbnailUrl)
                        .size(128, 128)
                        .allowHardware(false)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    colorFilter = colorFilter,
                    alignment = Alignment.TopStart,
                    modifier =
                      Modifier.fillMaxSize().blur(120.dp).graphicsLayer {
                        rotationZ = fastRotation
                        alpha = 0.6f
                      },
                  )

                  AsyncImage(
                    model =
                      ImageRequest.Builder(context)
                        .data(thumbnailUrl)
                        .size(128, 128)
                        .allowHardware(false)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    colorFilter = colorFilter,
                    alignment = Alignment.BottomEnd,
                    modifier =
                      Modifier.fillMaxSize().blur(120.dp).graphicsLayer {
                        rotationZ = slowRotation
                        alpha = 0.5f
                      },
                  )

                  Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.2f)))
                  Box(
                    modifier =
                      Modifier.fillMaxSize()
                        .background(
                          Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.25f))
                          )
                        )
                  )
                }
              }
            }
          }
          PlayerBackgroundStyle.DEFAULT -> {}
        }
      }
    },
    onDismiss = {
      playerConnection.service.clearAutomix()
      playerConnection.player.stop()
      playerConnection.player.clearMediaItems()
      playerConnection.service.clearPersistedQueueFiles()
    },
    collapsedContent = {
      MiniPlayer(
        positionState = positionState,
        durationState = durationState,
        onClick = { state.expandSoft() },
      )
    },
  ) {
    val controlsContent: @Composable ColumnScope.(MediaMetadata) -> Unit = { mediaMetadata ->
      val coroutineScope = rememberCoroutineScope()
      val dislikedSongs by
        rememberPreference(key = DislikedSongsKey, defaultValue = emptySet<String>())
      val isDisliked =
        remember(dislikedSongs, mediaMetadata.id) {
          dislikedSongs.any { it.substringBefore("||") == mediaMetadata.id }
        }
      val onToggleDislike: () -> Unit = {
        val id = mediaMetadata.id
        val title = mediaMetadata.title
        val artist = mediaMetadata.artists.firstOrNull()?.name.orEmpty()
        val thumb = mediaMetadata.thumbnailUrl.orEmpty()
        val entry = "$id||$title||$artist||$thumb"

        coroutineScope.launch {
          val current = context.dataStore.data.first()[DislikedSongsKey] ?: emptySet()
          val isCurrentlyDisliked = current.any { it.substringBefore("||") == id }
          if (isCurrentlyDisliked) {
            val toRemove = current.filter { it.substringBefore("||") == id }.toSet()
            context.dataStore.edit { prefs ->
              val existing = prefs[DislikedSongsKey] ?: emptySet()
              prefs[DislikedSongsKey] = existing - toRemove
            }
            val existingSong = database.song(id).firstOrNull()
            if (existingSong != null) {
              database.query {
                update(existingSong.song.copy(hideFromQuickPicks = false))
              }
            }
            Toast.makeText(context, "Removed from disliked songs", Toast.LENGTH_SHORT).show()
          } else {
            context.dataStore.edit { prefs ->
              val existing = prefs[DislikedSongsKey] ?: emptySet()
              prefs[DislikedSongsKey] = existing + entry
            }
            if (currentSong?.song?.liked == true) {
              playerConnection.toggleLike()
            }
            val existingSong = database.song(id).firstOrNull()
            if (existingSong != null) {
              database.query {
                update(existingSong.song.copy(hideFromQuickPicks = true, liked = false))
              }
            }
            val matchingHistory =
              database.searchHistory().firstOrNull().orEmpty().filter {
                it.query.contains(title, ignoreCase = true) ||
                  title.contains(it.query, ignoreCase = true)
              }
            if (matchingHistory.isNotEmpty()) {
              database.query {
                matchingHistory.forEach { delete(it) }
              }
            }
            Toast.makeText(context, "Song disliked. Skipped to next track.", Toast.LENGTH_SHORT)
              .show()
            playerConnection.player.seekToNext()
          }
        }
      }

      val playPauseRoundness by
        animateDpAsState(
          targetValue = if (isPlaying) 24.dp else 36.dp,
          animationSpec = tween(durationMillis = 90, easing = LinearEasing),
          label = "playPauseRoundness",
        )

      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(horizontal = PlayerHorizontalPadding),
      ) {
        AnimatedContent(targetState = showInlineLyrics, label = "ThumbnailAnimation") { showLyrics
          ->
          if (showLyrics) {
            Row {
              if (hidePlayerThumbnail) {
                Box(
                  modifier =
                    Modifier.size(56.dp)
                      .clip(RoundedCornerShape(ThumbnailCornerRadius))
                      .background(MaterialTheme.colorScheme.surfaceVariant),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(
                    painter = painterResource(R.drawable.ic_launcher_nobg),
                    contentDescription = null,
                    modifier = Modifier.size(32.dp),
                    tint = textButtonColor.copy(alpha = 0.7f),
                  )
                }
              } else {
                Box(
                  contentAlignment = Alignment.Center,
                  modifier =
                    Modifier.size(56.dp).clip(RoundedCornerShape(ThumbnailCornerRadius)).clickable(
                      enabled = isFullScreen && enableLyricsThumbnailPlayPause
                    ) {
                      playerConnection.togglePlayPause()
                    },
                ) {
                  AsyncImage(
                    model = mediaMetadata.thumbnailUrl,
                    contentDescription = null,
                    contentScale = if (cropAlbumArt) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                  )

                  if (isFullScreen && enableLyricsThumbnailPlayPause) {
                    Box(
                      modifier =
                        Modifier.fillMaxSize()
                          .background(Color.Black.copy(alpha = if (isPlaying) 0f else 0.4f))
                    )

                    androidx.compose.animation.AnimatedVisibility(
                      visible = !isPlaying,
                      enter = fadeIn(),
                      exit = fadeOut(),
                    ) {
                      Icon(
                        painter =
                          painterResource(
                            if (playbackState == Player.STATE_ENDED) R.drawable.replay
                            else R.drawable.play
                          ),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp),
                      )
                    }
                  }
                }
              }
              Spacer(modifier = Modifier.width(12.dp))
            }
          } else {
            Spacer(modifier = Modifier.width(0.dp))
          }
        }
        Column(
          modifier =
            Modifier.weight(1f)
              .SwipeGesture(
                enabled = isFullScreen && swipeLyrics,
                onSwipeRight = { playerConnection.seekToPrevious() },
                onSwipeLeft = { playerConnection.seekToNext() },
              )
        ) {
          AnimatedContent(
            targetState = mediaMetadata.title,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "",
          ) { title ->
            Text(
              text = title,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              color = TextBackgroundColor,
              modifier =
                Modifier.basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                  .combinedClickable(
                    enabled = true,
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                    onClick = {
                      mediaMetadata.album?.let { album ->
                        navController.navigate("album/${album.id}")
                        state.collapseSoft()
                      }
                    },
                    onLongClick = {
                      val clip =
                        ClipData.newPlainText(context.getString(R.string.copied_title), title)
                      clipboardManager.setPrimaryClip(clip)
                      Toast.makeText(
                          context,
                          context.getString(R.string.copied_title),
                          Toast.LENGTH_SHORT,
                        )
                        .show()
                    },
                  ),
            )
          }

          Spacer(Modifier.height(4.dp))

          if (isCasting && castDeviceName != null) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp),
            ) {
              Icon(
                painter = painterResource(R.drawable.cast_connected),
                contentDescription = null,
                tint = TextBackgroundColor.copy(alpha = 0.7f),
                modifier = Modifier.size(14.dp),
              )
              Spacer(Modifier.width(4.dp))
              Text(
                text = "Casting to $castDeviceName",
                style = MaterialTheme.typography.labelMedium,
                color = TextBackgroundColor.copy(alpha = 0.7f),
              )
            }
            Spacer(Modifier.height(2.dp))
          }

          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            if (mediaMetadata.explicit) MIcon.Explicit(tint = TextBackgroundColor)

            if (mediaMetadata.artists.any { it.name.isNotBlank() }) {
              val annotatedString = buildAnnotatedString {
                mediaMetadata.artists.forEachIndexed { index, artist ->
                  val tag = "artist_${artist.id.orEmpty()}"
                  pushStringAnnotation(tag = tag, annotation = artist.id.orEmpty())
                  withStyle(SpanStyle(color = TextBackgroundColor, fontSize = 16.sp)) {
                    append(artist.name)
                  }
                  pop()
                  if (index != mediaMetadata.artists.lastIndex) append(", ")
                }
              }

              Box(
                modifier =
                  Modifier.fillMaxWidth()
                    .basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                    .padding(end = 12.dp)
              ) {
                var layoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
                var clickOffset by remember { mutableStateOf<Offset?>(null) }
                Text(
                  text = annotatedString,
                  style = MaterialTheme.typography.titleMedium.copy(color = TextBackgroundColor),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  onTextLayout = { layoutResult = it },
                  modifier =
                    Modifier.pointerInput(Unit) {
                        awaitPointerEventScope {
                          while (true) {
                            val event = awaitPointerEvent()
                            val tapPosition = event.changes.firstOrNull()?.position
                            if (tapPosition != null) {
                              clickOffset = tapPosition
                            }
                          }
                        }
                      }
                      .combinedClickable(
                        enabled = true,
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = {
                          val tapPosition = clickOffset
                          val layout = layoutResult
                          if (tapPosition != null && layout != null) {
                            val offset = layout.getOffsetForPosition(tapPosition)
                            annotatedString
                              .getStringAnnotations(offset, offset)
                              .firstOrNull()
                              ?.let { ann ->
                                val artistId = ann.item
                                if (artistId.isNotBlank()) {
                                  navController.navigate("artist/$artistId")
                                  state.collapseSoft()
                                }
                              }
                          }
                        },
                        onLongClick = {
                          val clip =
                            ClipData.newPlainText(
                              context.getString(R.string.copied_artist),
                              annotatedString,
                            )
                          clipboardManager.setPrimaryClip(clip)
                          Toast.makeText(
                              context,
                              context.getString(R.string.copied_artist),
                              Toast.LENGTH_SHORT,
                            )
                            .show()
                        },
                      ),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        if (useNewPlayerDesign) {
          val shareShape =
            RoundedCornerShape(
              topStart = 50.dp,
              bottomStart = 50.dp,
              topEnd = 3.dp,
              bottomEnd = 3.dp,
            )

          val favShape =
            RoundedCornerShape(
              topStart = 3.dp,
              bottomStart = 3.dp,
              topEnd = 50.dp,
              bottomEnd = 50.dp,
            )

          val middleShape = RoundedCornerShape(3.dp)

          Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            AnimatedContent(targetState = showInlineLyrics, label = "DownloadButton") { showLyrics
              ->
              if (showLyrics) {
                FilledIconButton(
                  onClick = { isFullScreen = !isFullScreen },
                  shape = shareShape,
                  colors =
                    IconButtonDefaults.filledIconButtonColors(
                      containerColor = textButtonColor,
                      contentColor = iconButtonColor,
                    ),
                  modifier = Modifier.size(42.dp),
                ) {
                  Icon(
                    painter =
                      painterResource(
                        if (isFullScreen) R.drawable.fullscreen_exit else R.drawable.fullscreen
                      ),
                    contentDescription =
                      stringResource(
                        if (isFullScreen) R.string.exit_fullscreen else R.string.enter_fullscreen
                      ),
                    modifier = Modifier.size(24.dp),
                  )
                }
              } else {
                FilledIconButton(
                  onClick = {
                    mediaMetadata?.let { meta ->
                      when (download?.state) {
                        Download.STATE_COMPLETED,
                        Download.STATE_QUEUED,
                        Download.STATE_DOWNLOADING -> {
                          DownloadService.sendRemoveDownload(
                            context,
                            ExoDownloadService::class.java,
                            meta.id,
                            false,
                          )
                        }
                        else -> {
                          database.transaction { insert(meta) }
                          val downloadRequest =
                            DownloadRequest.Builder(meta.id, meta.id.toUri())
                              .setCustomCacheKey(meta.id)
                              .setData(meta.title.toByteArray())
                              .build()
                          DownloadService.sendAddDownload(
                            context,
                            ExoDownloadService::class.java,
                            downloadRequest,
                            false,
                          )
                        }
                      }
                    }
                  },
                  shape = shareShape,
                  colors =
                    IconButtonDefaults.filledIconButtonColors(
                      containerColor = textButtonColor,
                      contentColor = iconButtonColor,
                    ),
                  modifier = Modifier.size(42.dp),
                ) {
                  when (download?.state) {
                    Download.STATE_COMPLETED -> {
                      Icon(
                        painter = painterResource(R.drawable.offline),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                      )
                    }
                    Download.STATE_QUEUED,
                    Download.STATE_DOWNLOADING -> {
                      CircularWavyProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                    else -> {
                      Icon(
                        painter = painterResource(R.drawable.download),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                      )
                    }
                  }
                }
              }
            }

            AnimatedContent(targetState = showInlineLyrics, label = "LikeButton") { showLyrics ->
              if (showLyrics) {
                val currentLyrics by playerConnection.currentLyrics.collectAsState(initial = null)
                FilledIconButton(
                  onClick = {
                    menuState.show {
                      echo.music.iad1tya.ui.menu.LyricsMenu(
                        lyricsProvider = { currentLyrics },
                        songProvider = { currentSong?.song },
                        mediaMetadataProvider = { mediaMetadata },
                        onDismiss = menuState::dismiss,
                        onShowOffsetDialog = {
                          bottomSheetPageState.show {
                            ShowOffsetDialog(songProvider = { currentSong?.song })
                          }
                        },
                      )
                    }
                  },
                  shape = favShape,
                  colors =
                    IconButtonDefaults.filledIconButtonColors(
                      containerColor = textButtonColor,
                      contentColor = iconButtonColor,
                    ),
                  modifier = Modifier.size(42.dp),
                ) {
                  Icon(
                    painter = painterResource(R.drawable.more_horiz),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                  )
                }
              } else {
                Row(
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  FilledIconButton(
                    onClick = onToggleDislike,
                    shape = middleShape,
                    colors =
                      IconButtonDefaults.filledIconButtonColors(
                        containerColor =
                          if (isDisliked)
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)
                          else textButtonColor,
                        contentColor =
                          if (isDisliked) MaterialTheme.colorScheme.error else iconButtonColor,
                      ),
                    modifier = Modifier.size(42.dp),
                  ) {
                    Icon(
                      painter =
                        painterResource(
                          if (isDisliked) R.drawable.thumb_down_filled else R.drawable.thumb_down
                        ),
                      contentDescription = "Dislike",
                      tint = if (isDisliked) MaterialTheme.colorScheme.error else iconButtonColor,
                      modifier = Modifier.size(22.dp),
                    )
                  }

                  FilledIconButton(
                    onClick = playerConnection::toggleLike,
                    shape = favShape,
                    colors =
                      IconButtonDefaults.filledIconButtonColors(
                        containerColor = textButtonColor,
                        contentColor = iconButtonColor,
                      ),
                    modifier = Modifier.size(42.dp),
                  ) {
                    HeartBurstIcon(
                      isLiked = currentSong?.song?.liked == true,
                      iconSize = 24.dp,
                      unlikedColor = iconButtonColor,
                    )
                  }
                }
              }
            }
          }
        } else {
          AnimatedContent(targetState = showInlineLyrics, label = "DownloadButton") { showLyrics ->
            if (showLyrics) {
              Box(
                modifier =
                  Modifier.size(40.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(textButtonColor.copy(alpha = 0.2f))
                    .clickable { isFullScreen = !isFullScreen }
              ) {
                Icon(
                  painter =
                    painterResource(
                      if (isFullScreen) R.drawable.fullscreen_exit else R.drawable.fullscreen
                    ),
                  contentDescription =
                    stringResource(
                      if (isFullScreen) R.string.exit_fullscreen else R.string.enter_fullscreen
                    ),
                  tint = textButtonColor,
                  modifier = Modifier.align(Alignment.Center).size(24.dp),
                )
              }
            } else {
              Box(
                modifier =
                  Modifier.size(40.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(textButtonColor.copy(alpha = 0.2f))
                    .clickable {
                      menuState.show {
                        OldPlayerMenu(
                          mediaMetadata = mediaMetadata,
                          navController = navController,
                          playerBottomSheetState = state,
                          onShowDetailsDialog = {
                            mediaMetadata.id.let { bottomSheetPageState.show { ShowMediaInfo(it) } }
                          },
                          onDismiss = menuState::dismiss,
                        )
                      }
                    }
              ) {
                Icon(
                  painter = painterResource(R.drawable.more_vert),
                  contentDescription = null,
                  tint = textButtonColor,
                  modifier = Modifier.align(Alignment.Center).size(24.dp),
                )
              }
            }
          }

          if (!showInlineLyrics) {
            Spacer(modifier = Modifier.size(10.dp))

            Box(
              modifier =
                Modifier.size(40.dp)
                  .clip(RoundedCornerShape(24.dp))
                  .background(
                    if (isDisliked) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                    else textButtonColor.copy(alpha = 0.2f)
                  )
                  .clickable(onClick = onToggleDislike)
            ) {
              Icon(
                painter =
                  painterResource(
                    if (isDisliked) R.drawable.thumb_down_filled else R.drawable.thumb_down
                  ),
                contentDescription = "Dislike",
                tint = if (isDisliked) MaterialTheme.colorScheme.error else textButtonColor,
                modifier = Modifier.align(Alignment.Center).size(22.dp),
              )
            }
          }

          Spacer(modifier = Modifier.size(10.dp))

          AnimatedContent(targetState = showInlineLyrics, label = "LikeButton") { showLyrics ->
            if (showLyrics) {
              val currentLyrics by playerConnection.currentLyrics.collectAsState(initial = null)
              Box(
                modifier =
                  Modifier.size(40.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(textButtonColor.copy(alpha = 0.2f))
                    .clickable {
                      menuState.show {
                        echo.music.iad1tya.ui.menu.LyricsMenu(
                          lyricsProvider = { currentLyrics },
                          songProvider = { currentSong?.song },
                          mediaMetadataProvider = { mediaMetadata },
                          onDismiss = menuState::dismiss,
                          onShowOffsetDialog = {
                            bottomSheetPageState.show {
                              ShowOffsetDialog(songProvider = { currentSong?.song })
                            }
                          },
                        )
                      }
                    }
              ) {
                Icon(
                  painter = painterResource(R.drawable.more_horiz),
                  contentDescription = null,
                  tint = textButtonColor,
                  modifier = Modifier.align(Alignment.Center).size(24.dp),
                )
              }
            } else {
              Box(
                modifier =
                  Modifier.size(40.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(textButtonColor.copy(alpha = 0.2f))
                    .clickable(onClick = playerConnection::toggleLike)
              ) {
                Icon(
                  painter =
                    painterResource(
                      if (currentSong?.song?.liked == true) R.drawable.favorite
                      else R.drawable.favorite_border
                    ),
                  contentDescription = null,
                  tint = textButtonColor,
                  modifier = Modifier.align(Alignment.Center).size(24.dp),
                )
              }
            }
          }
        }
      }

      Spacer(Modifier.height(if (useNewPlayerDesign) 24.dp else 20.dp))

      when (sliderStyle) {
        SliderStyle.DEFAULT -> {
          Slider(
            value = (sliderPosition ?: effectivePosition).toFloat(),
            valueRange = 0f..(if (duration == C.TIME_UNSET) 0f else duration.toFloat()),
            onValueChange = {
              if (!isListenTogetherGuest) {
                sliderPosition = it.toLong()
              }
            },
            onValueChangeFinished = {
              if (!isListenTogetherGuest) {
                sliderPosition?.let {
                  if (isCasting) {
                    castHandler?.seekTo(it)
                    lastManualSeekTime = System.currentTimeMillis()
                  } else {
                    playerConnection.player.seekTo(it)
                  }
                  position = it
                }
                sliderPosition = null
              }
            },
            enabled = !isListenTogetherGuest,
            colors =
              PlayerSliderColors.getSliderColors(
                activeColor =
                  if (useNewPlayerDesign) textButtonColor else textButtonColor.copy(alpha = 0.7f),
                playerBackground = playerBackground,
                useDarkTheme = useDarkTheme,
              ),
            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
          )
        }
        SliderStyle.WAVY -> {
          if (squigglySlider) {
            SquigglySlider(
              value = (sliderPosition ?: effectivePosition).toFloat(),
              valueRange = 0f..(if (duration == C.TIME_UNSET) 0f else duration.toFloat()),
              onValueChange = { sliderPosition = it.toLong() },
              onValueChangeFinished = {
                sliderPosition?.let {
                  if (isCasting) {
                    castHandler?.seekTo(it)
                    lastManualSeekTime = System.currentTimeMillis()
                  } else {
                    playerConnection.player.seekTo(it)
                  }
                  position = it
                }
                sliderPosition = null
              },
              modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
              colors =
                PlayerSliderColors.getSliderColors(
                  activeColor =
                    if (useNewPlayerDesign) textButtonColor else textButtonColor.copy(alpha = 0.7f),
                  playerBackground = playerBackground,
                  useDarkTheme = useDarkTheme,
                ),
              isPlaying = effectiveIsPlaying,
            )
          } else {
            WavySlider(
              value = (sliderPosition ?: effectivePosition).toFloat(),
              valueRange = 0f..(if (duration == C.TIME_UNSET) 0f else duration.toFloat()),
              onValueChange = { sliderPosition = it.toLong() },
              onValueChangeFinished = {
                sliderPosition?.let {
                  if (isCasting) {
                    castHandler?.seekTo(it)
                    lastManualSeekTime = System.currentTimeMillis()
                  } else {
                    playerConnection.player.seekTo(it)
                  }
                  position = it
                }
                sliderPosition = null
              },
              colors =
                PlayerSliderColors.getSliderColors(
                  activeColor =
                    if (useNewPlayerDesign) textButtonColor else textButtonColor.copy(alpha = 0.7f),
                  playerBackground = playerBackground,
                  useDarkTheme = useDarkTheme,
                ),
              modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
              isPlaying = effectiveIsPlaying,
            )
          }
        }
        SliderStyle.SLIM -> {
          val trackInteractionSource = remember { MutableInteractionSource() }
          val isTrackDragged by trackInteractionSource.collectIsDraggedAsState()
          val isTrackPressed by trackInteractionSource.collectIsPressedAsState()
          val isTrackActive = (isTrackDragged || isTrackPressed) && !useNewPlayerDesign

          val trackHeight by
            animateDpAsState(
              targetValue = if (isTrackActive) 16.dp else 10.dp,
              animationSpec =
                spring(
                  dampingRatio = Spring.DampingRatioMediumBouncy,
                  stiffness = Spring.StiffnessMedium,
                ),
              label = "trackHeight",
            )

          Slider(
            value = (sliderPosition ?: effectivePosition).toFloat(),
            valueRange = 0f..(if (duration == C.TIME_UNSET) 0f else duration.toFloat()),
            onValueChange = {
              if (!isListenTogetherGuest) {
                sliderPosition = it.toLong()
              }
            },
            onValueChangeFinished = {
              if (!isListenTogetherGuest) {
                sliderPosition?.let {
                  if (isCasting) {
                    castHandler?.seekTo(it)
                    lastManualSeekTime = System.currentTimeMillis()
                  } else {
                    playerConnection.player.seekTo(it)
                  }
                  position = it
                }
                sliderPosition = null
              }
            },
            enabled = !isListenTogetherGuest,
            interactionSource = trackInteractionSource,
            thumb = { Spacer(modifier = Modifier.size(0.dp)) },
            track = { sliderState ->
              PlayerSliderTrack(
                sliderState = sliderState,
                trackHeight = trackHeight,
                colors =
                  PlayerSliderColors.getSliderColors(
                    activeColor =
                      if (useNewPlayerDesign) textButtonColor
                      else textButtonColor.copy(alpha = 0.7f),
                    playerBackground = playerBackground,
                    useDarkTheme = useDarkTheme,
                  ),
              )
            },
            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
          )
        }
      }
      Spacer(Modifier.height(4.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(horizontal = PlayerHorizontalPadding + 4.dp),
      ) {
        Text(
          text = makeTimeString(sliderPosition ?: effectivePosition),
          style = MaterialTheme.typography.labelMedium,
          color = TextBackgroundColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        ) {
          val formatText =
            remember(currentAudioFormat, currentFormatEntity) {
              val localAudioFormat = currentAudioFormat
              val localFormatEntity = currentFormatEntity

              val sampleMime = localAudioFormat?.sampleMimeType?.lowercase().orEmpty()
              val entityMime = localFormatEntity?.mimeType?.lowercase().orEmpty()
              val entityCodecs = localFormatEntity?.codecs?.lowercase().orEmpty()

              val codecStr =
                when {
                  sampleMime.contains("alac") -> "ALAC"
                  sampleMime.contains("flac") -> "FLAC"
                  sampleMime.contains("opus") -> "OPUS"
                  sampleMime.contains("mp4a") || sampleMime.contains("aac") -> "AAC"
                  sampleMime.contains("mpeg") || sampleMime.contains("mp3") -> "MP3"
                  sampleMime.contains("vorbis") -> "VORBIS"
                  // Fallbacks if ExoPlayer track format not ready yet:
                  entityCodecs.contains("alac") || entityMime.contains("alac") -> "ALAC"
                  entityCodecs.contains("flac") || entityMime.contains("flac") -> "FLAC"
                  entityCodecs.contains("opus") ||
                    entityMime.contains("opus") ||
                    entityMime.contains("webm") -> "OPUS"
                  entityCodecs.contains("mp4a") ||
                    entityCodecs.contains("aac") ||
                    entityMime.contains("mp4") -> "AAC"
                  entityCodecs.contains("mp3") || entityMime.contains("mpeg") -> "MP3"
                  entityCodecs.isNotBlank() && entityCodecs != "unknown" -> entityCodecs.uppercase()
                  sampleMime.isNotBlank() -> sampleMime.substringAfter("audio/").uppercase()
                  entityMime.isNotBlank() -> entityMime.substringAfter("audio/").uppercase()
                  else -> ""
                }

              val rawBitrate =
                when {
                  localAudioFormat != null && localAudioFormat.bitrate > 0 ->
                    localAudioFormat.bitrate
                  localAudioFormat != null && localAudioFormat.averageBitrate > 0 ->
                    localAudioFormat.averageBitrate
                  localFormatEntity != null && localFormatEntity.bitrate > 0 -> {
                    // Guard against stale poisoned bitrate (e.g. 1411200 saved for an opus/aac
                    // stream)
                    if (
                      (codecStr == "OPUS" || codecStr == "AAC") &&
                        localFormatEntity.bitrate > 400000
                    ) {
                      if (codecStr == "OPUS") 160000 else 256000
                    } else {
                      localFormatEntity.bitrate
                    }
                  }
                  else -> 0
                }

              val bitrateStr = if (rawBitrate > 0) "${rawBitrate / 1000} kbps" else ""
              listOf(codecStr, bitrateStr).filter { it.isNotEmpty() }.joinToString(" • ")
            }

          val isBuffering = playbackState == androidx.media3.common.Player.STATE_BUFFERING

          // Beat-synced automix countdown: beats left until the planned mix point,
          // ticking with playback position and pulsing at the track's tempo.
          val mixBeatMs = automixDebug?.outBpm?.takeIf { it > 0f }?.let { 60_000f / it } ?: 500f
          val mixBeatsLeft =
            automixDebug?.triggerTimeMs?.let {
              kotlin.math.ceil((it - (sliderPosition ?: effectivePosition)) / mixBeatMs).toInt()
            }
          val mixCountdownActive = !isCrossfading && mixBeatsLeft != null && mixBeatsLeft in 1..16

          val shouldShowCodecBox =
            showCodecOnPlayer && (formatText.isNotEmpty() || isBuffering) ||
              isCrossfading ||
              mixCountdownActive

          if (dacDeviceState is DacDeviceState.Connected) {
            val connectedDac = dacDeviceState as DacDeviceState.Connected
            val caps = connectedDac.capabilities
            val bestRate = caps.supportedSampleRates.maxOrNull() ?: 96000
            val bestBits = caps.supportedFormats.maxOfOrNull { it.bitDepth } ?: 24
            BitPerfectBadge(
              sampleRate = bestRate,
              bitDepth = bestBits,
              uacVersion = caps.uacVersion,
            )
          }

          if (sleepTimerEnabled || shouldShowCodecBox) {
            Box(
              modifier =
                Modifier.clip(RoundedCornerShape(4.dp))
                  .background(TextBackgroundColor.copy(alpha = 0.08f))
                  .border(
                    width = 0.5.dp,
                    color = TextBackgroundColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(4.dp),
                  )
                  .clickable(enabled = sleepTimerEnabled) { showSleepTimerDialog = true }
                  .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              val codecBoxState =
                when {
                  sleepTimerEnabled -> 0
                  isCrossfading -> 1
                  mixCountdownActive -> 4
                  isBuffering -> 2
                  else -> 3
                }
              AnimatedContent(
                targetState = codecBoxState,
                transitionSpec = {
                  fadeIn(animationSpec = tween(300)) togetherWith
                    fadeOut(animationSpec = tween(300))
                },
                label = "QualityTimerSwitcher",
              ) { state ->
                when (state) {
                  0 -> {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Icon(
                        painter = painterResource(R.drawable.sleep_timer),
                        contentDescription = null,
                        tint = TextBackgroundColor.copy(alpha = 0.8f),
                        modifier = Modifier.size(12.dp),
                      )
                      Text(
                        text = makeTimeString(sleepTimerTimeLeft.coerceAtLeast(0)),
                        style =
                          MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                          ),
                        color = TextBackgroundColor.copy(alpha = 0.8f),
                        maxLines = 1,
                      )
                    }
                  }
                  1 -> {
                    val infiniteTransition =
                      androidx.compose.animation.core.rememberInfiniteTransition(
                        label = "ShiningCrossfade"
                      )
                    val alpha by
                      infiniteTransition.animateFloat(
                        initialValue = 0.3f,
                        targetValue = 1f,
                        animationSpec =
                          infiniteRepeatable(
                            animation = tween(800, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse,
                          ),
                        label = "CrossfadeAlpha",
                      )
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Icon(
                        painter =
                          painterResource(
                            if (isAutomixing) R.drawable.graphic_eq else R.drawable.sync
                          ),
                        contentDescription = if (isAutomixing) "Automixing" else "Crossfading",
                        tint = TextBackgroundColor.copy(alpha = alpha),
                        modifier = Modifier.size(12.dp),
                      )
                      Text(
                        text =
                          stringResource(
                            if (isAutomixing) R.string.automixing else R.string.crossfading
                          ),
                        style =
                          MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                          ),
                        color = TextBackgroundColor.copy(alpha = alpha),
                        maxLines = 1,
                      )
                    }
                  }
                  2 -> {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      androidx.compose.material3.CircularProgressIndicator(
                        modifier = Modifier.size(10.dp),
                        color = TextBackgroundColor.copy(alpha = 0.8f),
                        strokeWidth = 1.5.dp,
                      )
                      Text(
                        text = stringResource(R.string.loading),
                        style =
                          MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                          ),
                        color = TextBackgroundColor.copy(alpha = 0.8f),
                        maxLines = 1,
                      )
                    }
                  }
                  3 -> {
                    Text(
                      text = formatText,
                      style =
                        MaterialTheme.typography.labelSmall.copy(
                          fontWeight = FontWeight.Bold,
                          letterSpacing = 1.sp,
                          fontSize = 10.sp,
                        ),
                      color = TextBackgroundColor.copy(alpha = 0.8f),
                      maxLines = 1,
                    )
                  }
                  4 -> {
                    val beatTransition =
                      androidx.compose.animation.core.rememberInfiniteTransition(
                        label = "MixCountdownBeat"
                      )
                    val beatAlpha by
                      beatTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 0.35f,
                        animationSpec =
                          infiniteRepeatable(
                            animation =
                              tween(mixBeatMs.toInt().coerceIn(200, 1000), easing = LinearEasing),
                            repeatMode = RepeatMode.Restart,
                          ),
                        label = "MixCountdownAlpha",
                      )
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Icon(
                        painter = painterResource(R.drawable.graphic_eq),
                        contentDescription = null,
                        tint = TextBackgroundColor.copy(alpha = beatAlpha),
                        modifier = Modifier.size(12.dp),
                      )
                      Text(
                        text = stringResource(R.string.automix_mix_in, mixBeatsLeft ?: 0),
                        style =
                          MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                          ),
                        color = TextBackgroundColor.copy(alpha = beatAlpha),
                        maxLines = 1,
                      )
                    }
                  }
                }
              }
            }
          }
        }

        Text(
          text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
          style = MaterialTheme.typography.labelMedium,
          color = TextBackgroundColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          textAlign = TextAlign.End,
          modifier = Modifier.weight(1f),
        )
      }

      automixDebugOverlay()

      Spacer(Modifier.height(if (useNewPlayerDesign) 24.dp else 12.dp))

      AnimatedVisibility(
        visible = !isFullScreen,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit =
          shrinkVertically(shrinkTowards = Alignment.Top) +
            slideOutVertically(targetOffsetY = { it }) +
            fadeOut(),
      ) {
        Column {
          if (isEpisode) {
            EpisodeControls(
              enabled =
                !isListenTogetherGuest &&
                  (if (isCasting) castDuration > 0
                  else playerConnection.player.isCurrentMediaItemSeekable),
              color = TextBackgroundColor,
              onSeek = { offsetMs ->
                playerConnection.seekTo(
                  echo.music.iad1tya.playback.seekButtonTarget(
                    if (isCasting) castPosition else playerConnection.player.currentPosition,
                    if (isCasting) castDuration else playerConnection.player.duration,
                    offsetMs,
                  )
                )
              },
            )
          } else if (showSeekButtons && !useNewPlayerDesign) {
            SeekButtons(
              enabled =
                !isListenTogetherGuest &&
                  (if (isCasting) castDuration > 0
                  else playerConnection.player.isCurrentMediaItemSeekable),
              color = TextBackgroundColor,
              onSeek = { offsetMs ->
                val currentPosition =
                  if (isCasting) castPosition else playerConnection.player.currentPosition
                val currentDuration =
                  if (isCasting) castDuration else playerConnection.player.duration
                playerConnection.seekTo(
                  echo.music.iad1tya.playback.seekButtonTarget(
                    currentPosition,
                    currentDuration,
                    offsetMs,
                  )
                )
              },
            )
          }
          if (useNewPlayerDesign) {
            val seekButtonsEnabled =
              !isListenTogetherGuest &&
                (if (isCasting) castDuration > 0
                else playerConnection.player.isCurrentMediaItemSeekable)
            val seekBy: (Long) -> Unit = { offsetMs ->
              val currentPosition =
                if (isCasting) castPosition else playerConnection.player.currentPosition
              val currentDuration =
                if (isCasting) castDuration else playerConnection.player.duration
              playerConnection.seekTo(
                echo.music.iad1tya.playback.seekButtonTarget(
                  currentPosition,
                  currentDuration,
                  offsetMs,
                )
              )
            }

            val backInteractionSource = remember { MutableInteractionSource() }
            val nextInteractionSource = remember { MutableInteractionSource() }
            val playPauseInteractionSource = remember { MutableInteractionSource() }
            val seekBackInteractionSource = remember { MutableInteractionSource() }
            val seekForwardInteractionSource = remember { MutableInteractionSource() }

            val isPlayPausePressed by playPauseInteractionSource.collectIsPressedAsState()
            val isBackPressed by backInteractionSource.collectIsPressedAsState()
            var backLongPressFired by remember { mutableStateOf(false) }
            LaunchedEffect(isBackPressed) {
              if (isBackPressed) {
                backLongPressFired = false
                delay(1000L)
                backLongPressFired = true
                playerConnection.skipToPreviousItem()
              }
            }
            val isNextPressed by nextInteractionSource.collectIsPressedAsState()
            val isSeekBackPressed by seekBackInteractionSource.collectIsPressedAsState()
            val isSeekForwardPressed by seekForwardInteractionSource.collectIsPressedAsState()

            val playPauseScale by
              animateFloatAsState(
                targetValue = if (isPlayPausePressed) 0.9f else 1f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "playPauseScale",
              )

            val backButtonScale by
              animateFloatAsState(
                targetValue = if (isBackPressed) 0.9f else 1f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "backButtonScale",
              )

            val nextButtonScale by
              animateFloatAsState(
                targetValue = if (isNextPressed) 0.9f else 1f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "nextButtonScale",
              )

            val seekBackScale by
              animateFloatAsState(
                targetValue = if (isSeekBackPressed) 0.9f else 1f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "seekBackScale",
              )

            val seekForwardScale by
              animateFloatAsState(
                targetValue = if (isSeekForwardPressed) 0.9f else 1f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "seekForwardScale",
              )

            val mainButtonSize = if (showSeekButtons) 58.dp else 88.dp
            val mainButtonSquircle = RoundedCornerShape(if (showSeekButtons) 18.dp else 26.dp)
            val seekButtonSquircle = RoundedCornerShape(15.dp)

            Row(
              horizontalArrangement =
                if (showSeekButtons) Arrangement.SpaceEvenly else Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
              modifier =
                Modifier.fillMaxWidth()
                  .padding(horizontal = if (showSeekButtons) 8.dp else PlayerHorizontalPadding),
            ) {
              FilledIconButton(
                onClick = {
                  if (backLongPressFired) backLongPressFired = false
                  else playerConnection.seekToPrevious()
                },
                enabled = canSkipPrevious && !isListenTogetherGuest,
                shape = mainButtonSquircle,
                interactionSource = backInteractionSource,
                colors =
                  IconButtonDefaults.filledIconButtonColors(
                    containerColor = sideButtonContainerColor,
                    contentColor = sideButtonContentColor,
                  ),
                modifier =
                  Modifier.size(mainButtonSize).graphicsLayer {
                    scaleX = backButtonScale
                    scaleY = backButtonScale
                  },
              ) {
                Icon(
                  painter = painterResource(R.drawable.skip_previous),
                  contentDescription = null,
                  modifier = Modifier.size(if (showSeekButtons) 28.dp else 36.dp),
                )
              }

              if (showSeekButtons) {
                FilledIconButton(
                  onClick = { seekBy(-10_000L) },
                  enabled = seekButtonsEnabled,
                  shape = seekButtonSquircle,
                  interactionSource = seekBackInteractionSource,
                  colors =
                    IconButtonDefaults.filledIconButtonColors(
                      containerColor = sideButtonContainerColor,
                      contentColor = sideButtonContentColor,
                    ),
                  modifier =
                    Modifier.size(48.dp).graphicsLayer {
                      scaleX = seekBackScale
                      scaleY = seekBackScale
                    },
                ) {
                  Icon(
                    painter = painterResource(R.drawable.ic_replay_10),
                    contentDescription = stringResource(R.string.seek_back_ten_seconds),
                    modifier = Modifier.size(24.dp),
                  )
                }
              } else {
                Spacer(modifier = Modifier.width(16.dp))
              }

              val cookieIndent by
                animateFloatAsState(
                  targetValue = if (effectiveIsPlaying) 0.08f else 0f,
                  animationSpec = tween(durationMillis = 300, easing = LinearEasing),
                  label = "cookieIndent",
                )

              val infiniteTransition = rememberInfiniteTransition(label = "rotation")
              val rotation by
                infiniteTransition.animateFloat(
                  initialValue = 0f,
                  targetValue = 360f,
                  animationSpec =
                    infiniteRepeatable(
                      animation = tween(8000, easing = LinearEasing),
                      repeatMode = RepeatMode.Restart,
                    ),
                  label = "rotation",
                )

              FilledIconButton(
                onClick = {
                  if (isListenTogetherGuest) {
                    playerConnection.toggleMute()
                    return@FilledIconButton
                  }
                  if (isCasting) {
                    if (castIsPlaying) {
                      castHandler?.pause()
                    } else {
                      castHandler?.play()
                    }
                  } else if (playbackState == STATE_ENDED) {
                    playerConnection.player.seekTo(0, 0)
                    playerConnection.player.playWhenReady = true
                  } else {
                    playerConnection.togglePlayPause()
                  }
                },
                shape =
                  if (wavyPlayPause && cookieIndent > 0f) WavyShape(9, cookieIndent, rotation)
                  else mainButtonSquircle,
                interactionSource = playPauseInteractionSource,
                colors =
                  IconButtonDefaults.filledIconButtonColors(
                    containerColor = textButtonColor,
                    contentColor = iconButtonColor,
                  ),
                modifier =
                  Modifier.size(mainButtonSize).graphicsLayer {
                    scaleX = playPauseScale
                    scaleY = playPauseScale
                  },
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.Center,
                ) {
                  Icon(
                    painter =
                      painterResource(
                        if (isListenTogetherGuest) {
                          if (isMuted) R.drawable.volume_off else R.drawable.volume_up
                        } else {
                          if (effectiveIsPlaying) R.drawable.pause else R.drawable.play
                        }
                      ),
                    contentDescription =
                      if (isListenTogetherGuest) {
                        if (isMuted) stringResource(R.string.unmute)
                        else stringResource(R.string.mute)
                      } else {
                        if (effectiveIsPlaying) stringResource(R.string.pause)
                        else stringResource(R.string.play)
                      },
                    modifier = Modifier.size(if (showSeekButtons) 30.dp else 38.dp),
                  )
                }
              }

              if (showSeekButtons) {
                FilledIconButton(
                  onClick = { seekBy(10_000L) },
                  enabled = seekButtonsEnabled,
                  shape = seekButtonSquircle,
                  interactionSource = seekForwardInteractionSource,
                  colors =
                    IconButtonDefaults.filledIconButtonColors(
                      containerColor = sideButtonContainerColor,
                      contentColor = sideButtonContentColor,
                    ),
                  modifier =
                    Modifier.size(48.dp).graphicsLayer {
                      scaleX = seekForwardScale
                      scaleY = seekForwardScale
                    },
                ) {
                  Icon(
                    painter = painterResource(R.drawable.ic_forward_10),
                    contentDescription = stringResource(R.string.seek_forward_ten_seconds),
                    modifier = Modifier.size(24.dp),
                  )
                }
              } else {
                Spacer(modifier = Modifier.width(16.dp))
              }

              FilledIconButton(
                onClick = playerConnection::seekToNext,
                enabled = canSkipNext && !isListenTogetherGuest,
                shape = mainButtonSquircle,
                interactionSource = nextInteractionSource,
                colors =
                  IconButtonDefaults.filledIconButtonColors(
                    containerColor = sideButtonContainerColor,
                    contentColor = sideButtonContentColor,
                  ),
                modifier =
                  Modifier.size(mainButtonSize).graphicsLayer {
                    scaleX = nextButtonScale
                    scaleY = nextButtonScale
                  },
              ) {
                Icon(
                  painter = painterResource(R.drawable.skip_next),
                  contentDescription = null,
                  modifier = Modifier.size(if (showSeekButtons) 28.dp else 36.dp),
                )
              }
            }
          } else {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth().padding(horizontal = PlayerHorizontalPadding),
            ) {
              Box(modifier = Modifier.weight(1f)) {
                ResizableIconButton(
                  icon = R.drawable.apple_skip_previous,
                  enabled = canSkipPrevious && !isListenTogetherGuest,
                  color = TextBackgroundColor,
                  modifier =
                    Modifier.size(48.dp)
                      .align(Alignment.Center)
                      .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                  onClick = playerConnection::seekToPrevious,
                )
              }

              Spacer(Modifier.width(8.dp))

              Box(
                modifier =
                  Modifier.size(100.dp).clip(RoundedCornerShape(playPauseRoundness)).clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                  ) {
                    if (isListenTogetherGuest) {
                      playerConnection.toggleMute()
                      return@clickable
                    }
                    if (isCasting) {
                      if (castIsPlaying) {
                        castHandler?.pause()
                      } else {
                        castHandler?.play()
                      }
                    } else if (playbackState == STATE_ENDED) {
                      playerConnection.player.seekTo(0, 0)
                      playerConnection.player.playWhenReady = true
                    } else {
                      playerConnection.player.togglePlayPause()
                    }
                  }
              ) {
                Image(
                  painter =
                    painterResource(
                      if (isListenTogetherGuest) {
                        if (isMuted) R.drawable.volume_off else R.drawable.volume_up
                      } else if (playbackState == STATE_ENDED) {
                        R.drawable.replay
                      } else if (effectiveIsPlaying) {
                        R.drawable.pause_applemusic
                      } else {
                        R.drawable.play_applemusic
                      }
                    ),
                  contentDescription = null,
                  colorFilter = ColorFilter.tint(TextBackgroundColor),
                  modifier = Modifier.align(Alignment.Center).size(72.dp),
                )
              }

              Spacer(Modifier.width(8.dp))

              Box(modifier = Modifier.weight(1f)) {
                ResizableIconButton(
                  icon = R.drawable.apple_skip_next,
                  enabled = canSkipNext && !isListenTogetherGuest,
                  color = TextBackgroundColor,
                  modifier =
                    Modifier.size(48.dp)
                      .align(Alignment.Center)
                      .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                  onClick = playerConnection::seekToNext,
                )
              }
            }

            if (!hidePlayerSlider) {
              Spacer(modifier = Modifier.height(8.dp))

              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = PlayerHorizontalPadding),
              ) {
                val volumeInteractionSource = remember { MutableInteractionSource() }
                val isVolumeDragged by volumeInteractionSource.collectIsDraggedAsState()
                val isVolumePressed by volumeInteractionSource.collectIsPressedAsState()
                val isVolumeActive = isVolumeDragged || isVolumePressed

                var dragVolume by remember { mutableFloatStateOf(systemVolume) }

                val scope = rememberCoroutineScope()

                LaunchedEffect(systemVolume) { if (!isVolumeActive) dragVolume = systemVolume }

                val animatedSystemVolume by
                  animateFloatAsState(
                    targetValue = systemVolume,
                    animationSpec = tween(150, easing = LinearOutSlowInEasing),
                    label = "animatedSystemVolume",
                  )

                val volume =
                  if (isCasting) castVolume
                  else {
                    if (isVolumeActive) dragVolume else animatedSystemVolume
                  }

                val volumeTrackHeight by
                  animateDpAsState(
                    targetValue = if (isVolumeActive) 16.dp else 10.dp,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 600f),
                    label = "volumeTrackHeight",
                  )

                val volumeIconScale by
                  animateFloatAsState(
                    targetValue = if (isVolumeActive) 1.15f else 1f,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 600f),
                    label = "volumeIconScale",
                  )

                Icon(
                  painter = painterResource(R.drawable.volume_mute),
                  contentDescription = null,
                  tint = textButtonColor,
                  modifier =
                    Modifier.size(20.dp)
                      .graphicsLayer(scaleX = volumeIconScale, scaleY = volumeIconScale),
                )

                Spacer(Modifier.width(12.dp))

                Slider(
                  value = volume,
                  onValueChange = { newVolume ->
                    dragVolume = newVolume
                    if (isCasting) {
                      castHandler?.setVolume(newVolume)
                    } else {
                      scope.launch(Dispatchers.Default) {
                        val newStep = (newVolume * maxSystemVolume).roundToInt()
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newStep, 0)
                      }
                    }
                  },
                  modifier = Modifier.weight(1f),
                  interactionSource = volumeInteractionSource,
                  thumb = {},
                  track = { sliderState ->
                    PlayerSliderTrack(
                      sliderState = sliderState,
                      colors =
                        SliderDefaults.colors(
                          activeTrackColor = textButtonColor.copy(alpha = 0.7f),
                          inactiveTrackColor = textButtonColor.copy(alpha = 0.15f),
                        ),
                      trackHeight = volumeTrackHeight,
                    )
                  },
                )

                Spacer(Modifier.width(12.dp))

                Icon(
                  painter = painterResource(R.drawable.volume_up),
                  contentDescription = null,
                  tint = textButtonColor,
                  modifier =
                    Modifier.size(20.dp)
                      .graphicsLayer(scaleX = volumeIconScale, scaleY = volumeIconScale),
                )
              }
            }

            val displayBluetoothName =
              remember(bluetoothDeviceName) {
                if (bluetoothDeviceName != null) bluetoothDeviceName else bluetoothDeviceName
              }

            var lastNonNullName by remember { mutableStateOf<String?>(null) }
            LaunchedEffect(bluetoothDeviceName) {
              if (bluetoothDeviceName != null) lastNonNullName = bluetoothDeviceName
            }

            val hasBtConnection = bluetoothDeviceName != null || bluetoothTelemetry.isConnected
            AnimatedVisibility(
              visible = !useNewPlayerDesign && hasBtConnection,
              enter = fadeIn(tween(400)) + expandVertically(tween(400)),
              exit = fadeOut(tween(400)) + shrinkVertically(tween(400)),
              label = "BluetoothInfoVisibility",
            ) {
              val nameToShow =
                when {
                  bluetoothTelemetry.isConnected && bluetoothTelemetry.hasNamedCodec -> {
                    val baseName =
                      bluetoothTelemetry.deviceName
                        ?: bluetoothDeviceName
                        ?: lastNonNullName
                        ?: "Bluetooth Device"
                    val rateStr =
                      bluetoothTelemetry.sampleRateHz?.let { " / ${it / 1000}kHz" } ?: ""
                    val bitsStr = bluetoothTelemetry.bitDepth?.let { " $it-bit" } ?: ""
                    "$baseName • ${bluetoothTelemetry.codecName}$bitsStr$rateStr"
                  }
                  else -> bluetoothDeviceName ?: lastNonNullName ?: "Bluetooth Device"
                }
              Column {
                Spacer(Modifier.height(8.dp))
                Row(
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Icon(
                    painter =
                      painterResource(
                        when {
                          isSpeaker(nameToShow) -> R.drawable.speaker_applemusic
                          isBuds(nameToShow) -> R.drawable.apple_airpods
                          else -> R.drawable.apple_headset
                        }
                      ),
                    contentDescription = null,
                    tint =
                      if (bluetoothTelemetry.isHighRes) MaterialTheme.colorScheme.primary
                      else textButtonColor.copy(alpha = 0.7f),
                    modifier =
                      Modifier.size(
                        when {
                          isSpeaker(nameToShow) -> 18.dp
                          isBuds(nameToShow) -> 20.dp
                          else -> 16.dp
                        }
                      ),
                  )
                  Spacer(Modifier.width(6.dp))
                  Text(
                    text = nameToShow,
                    style = MaterialTheme.typography.labelSmall,
                    color =
                      if (bluetoothTelemetry.isHighRes) MaterialTheme.colorScheme.primary
                      else textButtonColor.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }
            }
          }
        }
      }
    }

    when (LocalConfiguration.current.orientation) {
      Configuration.ORIENTATION_LANDSCAPE -> {

        val density = LocalDensity.current
        val verticalPadding =
          max(WindowInsets.systemBars.getTop(density), WindowInsets.systemBars.getBottom(density))
        val verticalPaddingDp = with(density) { verticalPadding.toDp() }
        val verticalWindowInsets =
          WindowInsets(
            left = 0.dp,
            top = verticalPaddingDp,
            right = 0.dp,
            bottom = verticalPaddingDp,
          )

        Row(
          modifier =
            Modifier.windowInsetsPadding(
                WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).add(verticalWindowInsets)
              )
              .padding(bottom = 24.dp)
              .fillMaxSize()
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.weight(1f).nestedScroll(state.preUpPostDownNestedScrollConnection),
          ) {
            val currentSliderPosition by rememberUpdatedState(sliderPosition)
            val sliderPositionProvider = remember { { currentSliderPosition } }
            val isExpandedProvider = remember(state) { { state.isExpanded } }
            AnimatedContent(
              targetState = showInlineLyrics,
              label = "Lyrics",
              transitionSpec = { fadeIn() togetherWith fadeOut() },
              modifier = Modifier.fillMaxSize(),
            ) { showLyrics ->
              if (showLyrics) {
                InlineLyricsView(
                  mediaMetadata = mediaMetadata,
                  showLyrics = showLyrics,
                  positionProvider = { effectivePosition },
                )
              } else {
                Thumbnail(
                  sliderPositionProvider = sliderPositionProvider,
                  modifier = Modifier.fillMaxSize().animateContentSize(),
                  isPlayerExpanded = isExpandedProvider,
                  isLandscape = true,
                  isListenTogetherGuest = isListenTogetherGuest,
                )
              }
            }

            PlayerTopPill(
              modifier = Modifier.align(Alignment.TopCenter).zIndex(10f).padding(top = 8.dp),
              selectedOption = PlayerPillOption.SONG,
              onOptionSelected = { option ->
                when (option) {
                  PlayerPillOption.SONG -> {}
                  PlayerPillOption.VIDEO -> {
                    if (isLocalMedia) {
                      Toast.makeText(
                          context,
                          "Video unavailable for local tracks",
                          Toast.LENGTH_SHORT,
                        )
                        .show()
                    } else {
                      navController.navigate("podcast_video") { launchSingleTop = true }
                    }
                  }
                  PlayerPillOption.MUSIC_FLOW -> {
                    navController.navigate("music_flow") { launchSingleTop = true }
                    state.collapseSoft()
                  }
                }
              },
              isLightBackground = isTopLight,
              musicFlowEnabled = musicFlowEnabled && !isEpisode,
              firstTabTitle = if (isEpisode) "Episode" else "Song",
              firstTabIcon = if (isEpisode) R.drawable.radio else R.drawable.music_note,
            )
          }

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier =
              Modifier.weight(if (showInlineLyrics) 0.65f else 1f, false)
                .animateContentSize()
                .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Top)),
          ) {
            Spacer(Modifier.weight(1f))

            if (showLyricsOnPlayer && !showInlineLyrics) {
              PlayerSyncedLyricsView(
                mediaMetadata = mediaMetadata,
                positionProvider = { effectivePosition },
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
              )
            }

            mediaMetadata?.let { controlsContent(it) }

            Spacer(Modifier.weight(1f))
          }
        }
      }
      else -> {
        val bottomPadding by
          animateDpAsState(
            targetValue = if (isFullScreen) 0.dp else queueSheetState.collapsedBound,
            label = "bottomPadding",
          )
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier =
            Modifier.windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
              .padding(bottom = bottomPadding)
              .animateContentSize(),
        ) {
          Box(
            contentAlignment = Alignment.TopCenter,
            modifier = Modifier.weight(1f),
          ) {
            val currentSliderPosition by rememberUpdatedState(sliderPosition)
            val sliderPositionProvider = remember { { currentSliderPosition } }
            val isExpandedProvider = remember(state) { { state.isExpanded } }
            AnimatedContent(
              targetState = showInlineLyrics,
              label = "Lyrics",
              transitionSpec = { fadeIn() togetherWith fadeOut() },
              modifier = Modifier.fillMaxSize(),
            ) { showLyrics ->
              if (showLyrics) {
                InlineLyricsView(
                  mediaMetadata = mediaMetadata,
                  showLyrics = showLyrics,
                  positionProvider = { effectivePosition },
                )
              } else {
                Thumbnail(
                  sliderPositionProvider = sliderPositionProvider,
                  modifier =
                    Modifier.fillMaxSize().nestedScroll(state.preUpPostDownNestedScrollConnection),
                  isPlayerExpanded = isExpandedProvider,
                  isListenTogetherGuest = isListenTogetherGuest,
                )
              }
            }

            PlayerTopPill(
              modifier =
                Modifier.align(Alignment.TopCenter)
                  .zIndex(10f)
                  .statusBarsPadding()
                  .padding(top = 10.dp),
              selectedOption = PlayerPillOption.SONG,
              onOptionSelected = { option ->
                when (option) {
                  PlayerPillOption.SONG -> {}
                  PlayerPillOption.VIDEO -> {
                    if (isLocalMedia) {
                      Toast.makeText(
                          context,
                          "Video unavailable for local tracks",
                          Toast.LENGTH_SHORT,
                        )
                        .show()
                    } else {
                      navController.navigate("podcast_video") { launchSingleTop = true }
                    }
                  }
                  PlayerPillOption.MUSIC_FLOW -> {
                    navController.navigate("music_flow") { launchSingleTop = true }
                    state.collapseSoft()
                  }
                }
              },
              isLightBackground = isTopLight,
              musicFlowEnabled = musicFlowEnabled && !isEpisode,
              firstTabTitle = if (isEpisode) "Episode" else "Song",
              firstTabIcon = if (isEpisode) R.drawable.radio else R.drawable.music_note,
            )
          }

          if (showLyricsOnPlayer && !showInlineLyrics) {
            PlayerSyncedLyricsView(
              mediaMetadata = mediaMetadata,
              positionProvider = { effectivePosition },
              modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            )
          }

          mediaMetadata?.let { controlsContent(it) }

          Spacer(Modifier.height(if (useNewPlayerDesign) 30.dp else 8.dp))
        }
      }
    }

    AnimatedVisibility(
      visible = !isFullScreen,
      enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
      exit =
        shrinkVertically(shrinkTowards = Alignment.Top) +
          slideOutVertically(targetOffsetY = { it }) +
          fadeOut(),
    ) {
      Queue(
        state = queueSheetState,
        playerBottomSheetState = state,
        navController = navController,
        background =
          if (useBlackBackground) {
            Color.Black
          } else {
            MaterialTheme.colorScheme.surface
          },
        onBackgroundColor = onBackgroundColor,
        TextBackgroundColor = TextBackgroundColor,
        textButtonColor = textButtonColor,
        iconButtonColor = iconButtonColor,
        pureBlack = pureBlack,
        showInlineLyrics = showInlineLyrics,
        playerBackground = playerBackground,
        onToggleLyrics = { showInlineLyrics = !showInlineLyrics },
      )
    }
  }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun InlineLyricsView(
  mediaMetadata: MediaMetadata?,
  showLyrics: Boolean,
  modifier: Modifier = Modifier,
  positionProvider: () -> Long,
) {
  val playerConnection = LocalPlayerConnection.current ?: return
  val currentLyrics by playerConnection.currentLyrics.collectAsState(initial = null)
  val lyrics = remember(currentLyrics) { currentLyrics?.lyrics?.trim() }
  val context = LocalContext.current
  val database = LocalDatabase.current
  val coroutineScope = rememberCoroutineScope()

  LaunchedEffect(mediaMetadata?.id, currentLyrics) {
    if (mediaMetadata != null && currentLyrics == null) {
      delay(500)
      coroutineScope.launch(Dispatchers.IO) {
        try {
          val existing = database.lyrics(mediaMetadata.id).firstOrNull()
          if (existing != null) return@launch
          val entryPoint =
            EntryPointAccessors.fromApplication(
              context.applicationContext,
              echo.music.iad1tya.di.LyricsHelperEntryPoint::class.java,
            )
          val lyricsHelper = entryPoint.lyricsHelper()
          val fetchedLyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
          database.query {
            upsert(
              LyricsEntity(
                mediaMetadata.id,
                fetchedLyricsWithProvider.lyrics ?: "",
                fetchedLyricsWithProvider.providerName,
              )
            )
          }
        } catch (e: Exception) {}
      }
    }
  }

  Box(
    modifier = modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
    contentAlignment = Alignment.Center,
  ) {
    when {
      lyrics == null -> {
        ContainedLoadingIndicator()
      }
      lyrics == LyricsEntity.LYRICS_NOT_FOUND -> {
        Text(
          text = stringResource(R.string.lyrics_not_found),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
          textAlign = TextAlign.Center,
        )
      }
      else -> {
        val lyricsContent: @Composable () -> Unit = {
          Lyrics(
            sliderPositionProvider = positionProvider,
            modifier = Modifier.padding(horizontal = 24.dp),
            showLyrics = showLyrics,
          )
        }
        ProvideTextStyle(
          value =
            MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, textAlign = TextAlign.Center)
        ) {
          lyricsContent()
        }
      }
    }
  }
}

@Composable
fun MoreActionsButton(
  mediaMetadata: MediaMetadata,
  navController: NavController,
  state: BottomSheetState,
  textButtonColor: Color,
  iconButtonColor: Color,
) {
  val menuState = LocalMenuState.current
  val bottomSheetPageState = LocalBottomSheetPageState.current

  Box(
    modifier =
      Modifier.size(40.dp).clip(RoundedCornerShape(24.dp)).background(textButtonColor).clickable {
        menuState.show {
          PlayerMenu(
            mediaMetadata = mediaMetadata,
            navController = navController,
            playerBottomSheetState = state,
            onShowDetailsDialog = {
              mediaMetadata.id.let { bottomSheetPageState.show { ShowMediaInfo(it) } }
            },
            onDismiss = menuState::dismiss,
          )
        }
      }
  ) {
    Image(
      painter = painterResource(R.drawable.more_vert),
      contentDescription = null,
      colorFilter = ColorFilter.tint(iconButtonColor),
    )
  }
}

@Composable
private fun PlayerMoreMenuButton(
  mediaMetadata: MediaMetadata,
  navController: NavController,
  state: BottomSheetState,
  textButtonColor: Color,
  iconButtonColor: Color,
) {
  val menuState = LocalMenuState.current
  val bottomSheetPageState = LocalBottomSheetPageState.current

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      Modifier.size(40.dp).clip(RoundedCornerShape(24.dp)).background(textButtonColor).clickable {
        menuState.show {
          PlayerMenu(
            mediaMetadata = mediaMetadata,
            navController = navController,
            playerBottomSheetState = state,
            onShowDetailsDialog = {
              mediaMetadata.id.let { bottomSheetPageState.show { ShowMediaInfo(it) } }
            },
            onDismiss = menuState::dismiss,
          )
        }
      },
  ) {
    Image(
      painter = painterResource(R.drawable.more_horiz),
      contentDescription = null,
      colorFilter = ColorFilter.tint(iconButtonColor),
    )
  }
}

@Composable
private fun BackgroundVideoView(
  videoUrl: String,
  isPlaying: Boolean,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var isVideoReady by remember(videoUrl) { mutableStateOf(false) }

  val trackSelector = remember {
    DefaultTrackSelector(context).apply {
      parameters =
        buildUponParameters()
          .setMaxVideoSize(4096, 4096)
          .setForceHighestSupportedBitrate(true)
          .build()
    }
  }

  val exoPlayer = remember {
    ExoPlayer.Builder(context)
      .setTrackSelector(trackSelector)
      .setLoadControl(DefaultLoadControl.Builder().setTargetBufferBytes(20 * 1024 * 1024).build())
      .build()
      .apply {
        repeatMode = Player.REPEAT_MODE_ONE
        volume = 0f
        videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        playWhenReady = isPlaying
      }
  }

  val aspectRatioFrameLayout = remember {
    AspectRatioFrameLayout(context).apply {
      resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
      setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }
  }

  DisposableEffect(exoPlayer) {
    val listener =
      object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
          if (videoSize.width > 0 && videoSize.height > 0) {
            aspectRatioFrameLayout.setAspectRatio(videoSize.width.toFloat() / videoSize.height)
          }
        }

        override fun onRenderedFirstFrame() {
          isVideoReady = true
        }
      }
    exoPlayer.addListener(listener)
    onDispose { exoPlayer.removeListener(listener) }
  }

  LaunchedEffect(videoUrl) {
    isVideoReady = false
    val mediaItem =
      MediaItem.Builder()
        .setUri(videoUrl)
        .setMimeType(
          if (videoUrl.contains("m3u8")) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP4
        )
        .build()
    exoPlayer.setMediaItem(mediaItem)
    exoPlayer.prepare()
  }

  LaunchedEffect(isPlaying) { exoPlayer.playWhenReady = isPlaying }

  DisposableEffect(Unit) { onDispose { exoPlayer.release() } }

  val alpha by
    animateFloatAsState(
      targetValue = if (isVideoReady) 1f else 0f,
      animationSpec = tween(800),
      label = "videoAlpha",
    )

  AndroidView(
    factory = { _ ->
      aspectRatioFrameLayout.apply {
        isEnabled = false
        isClickable = false
        isFocusable = false

        if (childCount == 0) {
          val textureView =
            TextureView(context).apply {
              layoutParams = ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            }
          addView(textureView)
          exoPlayer.setVideoTextureView(textureView)
        }
      }
    },
    modifier = modifier.alpha(alpha),
  )
}

enum class PlayerPillOption {
  SONG,
  VIDEO,
  MUSIC_FLOW,
}

@Composable
fun PlayerTopPill(
  selectedOption: PlayerPillOption,
  onOptionSelected: (PlayerPillOption) -> Unit,
  isLightBackground: Boolean,
  modifier: Modifier = Modifier,
  musicFlowEnabled: Boolean = true,
  firstTabTitle: String = "Song",
  firstTabIcon: Int = R.drawable.music_note,
) {
  val pillContentColor = if (isLightBackground) Color(0xFF1A1A1A) else Color.White
  val pillContainerColor =
    if (isLightBackground) Color.White.copy(alpha = 0.88f) else Color.Black.copy(alpha = 0.45f)
  val pillBorderColor =
    if (isLightBackground) Color.Black.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.22f)
  val selectedBgColor =
    if (isLightBackground) Color.Black.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.22f)
  val unselectedContentColor =
    if (isLightBackground) Color.Black.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.75f)

  Surface(
    shape = CircleShape,
    color = pillContainerColor,
    contentColor = pillContentColor,
    border = BorderStroke(1.dp, pillBorderColor),
    modifier = modifier,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(3.dp),
    ) {
      PillTabItem(
        title = firstTabTitle,
        icon = firstTabIcon,
        isSelected = selectedOption == PlayerPillOption.SONG,
        contentColor = pillContentColor,
        selectedBgColor = selectedBgColor,
        unselectedContentColor = unselectedContentColor,
        onClick = { onOptionSelected(PlayerPillOption.SONG) },
      )

      PillTabItem(
        title = "Video",
        icon = R.drawable.ic_smart_display,
        isSelected = selectedOption == PlayerPillOption.VIDEO,
        contentColor = pillContentColor,
        selectedBgColor = selectedBgColor,
        unselectedContentColor = unselectedContentColor,
        onClick = { onOptionSelected(PlayerPillOption.VIDEO) },
      )

      if (musicFlowEnabled) {
        PillTabItem(
          title = stringResource(R.string.music_flow),
          icon = R.drawable.swipe_vertical,
          isSelected = selectedOption == PlayerPillOption.MUSIC_FLOW,
          contentColor = pillContentColor,
          selectedBgColor = selectedBgColor,
          unselectedContentColor = unselectedContentColor,
          onClick = { onOptionSelected(PlayerPillOption.MUSIC_FLOW) },
        )
      }
    }
  }
}

@Composable
private fun PillTabItem(
  title: String,
  icon: Int,
  isSelected: Boolean,
  contentColor: Color,
  selectedBgColor: Color,
  unselectedContentColor: Color,
  onClick: () -> Unit,
) {
  val backgroundModifier =
    if (isSelected) {
      Modifier.background(
        color = selectedBgColor,
        shape = CircleShape,
      )
    } else {
      Modifier
    }

  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier =
      Modifier.clip(CircleShape)
        .then(backgroundModifier)
        .clickable(role = Role.Tab, onClick = onClick)
        .padding(horizontal = 10.dp, vertical = 5.dp),
  ) {
    Icon(
      painter = painterResource(icon),
      contentDescription = null,
      tint = if (isSelected) contentColor else unselectedContentColor,
      modifier = Modifier.size(13.dp),
    )
    Spacer(Modifier.width(4.dp))
    Text(
      text = title,
      style =
        MaterialTheme.typography.labelSmall.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
          fontSize = 11.5.sp,
          letterSpacing = 0.2.sp,
        ),
      color = if (isSelected) contentColor else unselectedContentColor,
    )
  }
}

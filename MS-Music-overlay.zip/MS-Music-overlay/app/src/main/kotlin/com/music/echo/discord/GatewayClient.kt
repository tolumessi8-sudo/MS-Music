package echo.music.iad1tya.discord

import kotlin.random.Random
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber

private sealed class GatewayFrame {
  data class Text(
    val text: String,
  ) : GatewayFrame()

  data class Close(
    val code: Int,
    val reason: String,
  ) : GatewayFrame()
}

class GatewayClient {
  companion object {
    private const val TAG = "GatewayClient"
  }

  private var httpClient: OkHttpClient? = null
  @Volatile private var wsSession: WebSocket? = null
  private var processingJob: Job? = null
  private var heartbeatJob: Job? = null
  private var helloTimerJob: Job? = null
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
  private val incomingChannel = Channel<GatewayFrame>(Channel.UNLIMITED)

  private var lastAck = true
  private var lastHeartbeatAt = 0L
  private var ping = -1

  private var sessionState: GatewaySessionState? = null
  private var liveSeq = 0
  private var token = ""
  @Volatile private var closed = false

  var onReady: ((GatewayReadyEvent) -> Unit)? = null
  var onClose: ((GatewayCloseInfo) -> Unit)? = null
  var onError: ((Throwable) -> Unit)? = null
  var onDebug: ((String) -> Unit)? = null

  val latency: Int
    get() = ping

  val isConnected: Boolean
    get() = !closed && wsSession != null

  suspend fun connect(accessToken: String) {
    if (wsSession != null) throw IllegalStateException("GatewayClient already connected")

    token = accessToken
    sessionState = null
    liveSeq = 0
    closed = false
    lastAck = true

    val url = "${GatewayDefaults.GATEWAY_URL}/?v=${GatewayDefaults.GATEWAY_VERSION}&encoding=json"
    val ready = CompletableDeferred<Unit>()

    debug("connecting $url")

    httpClient = OkHttpClient.Builder().build()

    val request = Request.Builder().url(url).build()

    wsSession =
      httpClient!!.newWebSocket(
        request,
        object : WebSocketListener() {
          override fun onOpen(
            webSocket: WebSocket,
            response: Response,
          ) {
            response.close()
          }

          override fun onMessage(
            webSocket: WebSocket,
            text: String,
          ) {
            scope.launch { incomingChannel.send(GatewayFrame.Text(text)) }
          }

          override fun onClosing(
            webSocket: WebSocket,
            code: Int,
            reason: String,
          ) {
            scope.launch { incomingChannel.send(GatewayFrame.Close(code, reason)) }
          }

          override fun onClosed(
            webSocket: WebSocket,
            code: Int,
            reason: String,
          ) {
            scope.launch { incomingChannel.send(GatewayFrame.Close(code, reason)) }
          }

          override fun onFailure(
            webSocket: WebSocket,
            t: Throwable,
            response: Response?,
          ) {
            response?.close()
            scope.launch {
              incomingChannel.send(GatewayFrame.Close(1006, t.message ?: "websocket failure"))
            }
            onError?.invoke(t)
          }
        },
      )

    helloTimerJob =
      scope.launch {
        delay(GatewayDefaults.HELLO_TIMEOUT_MS)
        debug("HELLO timeout")
        wsSession?.close(4009, "HELLO timeout")
        ready.completeExceptionally(Exception("HELLO timeout"))
      }

    processingJob =
      scope.launch {
        try {
          for (frame in incomingChannel) {
            when (frame) {
              is GatewayFrame.Text -> {
                handleMessage(frame.text, ready)
              }
              is GatewayFrame.Close -> {
                handleClose(frame.reason, frame.code)
                if (!ready.isCompleted) {
                  ready.completeExceptionally(
                    Exception("Gateway closed before ready"),
                  )
                }
                break
              }
            }
          }
        } catch (e: Exception) {
          if (!ready.isCompleted) ready.completeExceptionally(e)
          onError?.invoke(e)
        }
      }

    ready.await()
  }

  fun sendPresenceUpdate(presenceJson: JSONObject): Boolean =
    send(GatewayOp.PRESENCE_UPDATE, presenceJson)

  fun disconnect() {
    closed = true
    stopHeartbeat()
    helloTimerJob?.cancel()
    processingJob?.cancel()
    scope.launch {
      wsSession?.close(1000, "Client disconnect")
      wsSession = null
      httpClient?.dispatcher?.executorService?.shutdown()
      httpClient = null
    }
  }

  private fun send(
    op: Int,
    d: Any?,
  ): Boolean {
    val session = wsSession ?: return false
    scope.launch {
      try {
        val jsonStr = buildJsonString(op, d)
        session.send(jsonStr)
      } catch (e: Exception) {
        onError?.invoke(e)
      }
    }
    return true
  }

  private fun buildJsonString(
    op: Int,
    d: Any?,
  ): String {
    val json = JSONObject()
    json.put("op", op)
    when (d) {
      is JSONObject -> json.put("d", d)
      is JSONArray -> json.put("d", d)
      is Map<*, *> -> json.put("d", JSONObject(d as Map<*, *>))
      is Int -> json.put("d", d)
      is String -> json.put("d", d)
      is Boolean -> json.put("d", d)
      null -> json.put("d", JSONObject.NULL)
      else -> json.put("d", d.toString())
    }
    return json.toString()
  }

  private fun handleMessage(
    raw: String,
    ready: CompletableDeferred<Unit>,
  ) {
    try {
      val json = JSONObject(raw)
      val op = json.getInt("op")
      val d = json.opt("d")
      val s = if (json.has("s") && !json.isNull("s")) json.getInt("s") else null
      val t = json.optString("t", null)

      if (s != null && s > liveSeq) {
        liveSeq = s
        touchSession(seq = s)
      }

      when (op) {
        GatewayOp.HELLO -> {
          helloTimerJob?.cancel()
          val dObj = d as JSONObject
          val interval = dObj.getInt("heartbeat_interval")
          startHeartbeat(interval.toLong())
          debug("HELLO received, heartbeat_interval=${interval}ms")
          sendIdentify()
        }
        GatewayOp.HEARTBEAT_ACK -> {
          lastAck = true
          ping = (System.currentTimeMillis() - lastHeartbeatAt).toInt()
          debug("heartbeat ack (${ping}ms)")
        }
        GatewayOp.HEARTBEAT -> {
          debug("received server heartbeat")
          sendHeartbeat(force = true)
        }
        GatewayOp.RECONNECT -> {
          debug("server requested RECONNECT")
          forceClose(4000, "server reconnect")
        }
        GatewayOp.INVALID_SESSION -> {
          val resumable = if (d is Boolean) d else false
          debug("INVALID_SESSION resumable=$resumable")
          if (!resumable) {
            sessionState = null
            touchSession(sessionId = null, resumeGatewayUrl = null, seq = 0)
          }
          forceClose(if (resumable) 4000 else 1000, "invalid session")
        }
        GatewayOp.DISPATCH -> {
          handleDispatch(t ?: "", d, s, ready)
        }
      }
    } catch (e: Exception) {
      onError?.invoke(e)
    }
  }

  private fun handleDispatch(
    t: String,
    d: Any?,
    s: Int?,
    ready: CompletableDeferred<Unit>,
  ) {
    when (t) {
      "READY" -> {
        val obj = d as JSONObject
        val re = GatewayReadyEvent.fromJson(obj)
        debug("READY: user=${re.user.username} (${re.user.id}) session=${re.sessionId}")
        sessionState = GatewaySessionState(re.sessionId, liveSeq, re.resumeGatewayUrl)
        touchSession(re.sessionId, liveSeq, re.resumeGatewayUrl)
        ready.complete(Unit)
        onReady?.invoke(re)
      }
      "RESUMED" -> {
        debug("RESUMED: session restored, seq=$liveSeq")
        touchSession(
          sessionState?.sessionId,
          liveSeq,
          sessionState?.resumeGatewayUrl,
        )
        ready.complete(Unit)
      }
      else -> {
        debug("dispatch $t")
      }
    }
  }

  private fun sendIdentify() {
    val capabilities = GatewayCapabilitiesFlags.FLAGS
    val intents = IntentsFlags.FLAGS

    val capsBitfield = capabilities.values.reduce { a, b -> a or b }
    val intentsBitfield = intents.values.reduce { a, b -> a or b }

    val d = JSONObject()
    d.put("capabilities", capsBitfield)
    d.put("intents", intentsBitfield)
    d.put("token", token)
    val properties = JSONObject()
    properties.put("os", "Android")
    properties.put("browser", "MS Music")
    properties.put("device", "Android")
    properties.put("browser_user_agent", "MS Music")
    properties.put("browser_version", "1.0")
    properties.put("client_version", "1.0")
    properties.put("client_build_number", 1)
    properties.put("native_build_number", 1)
    properties.put("release_channel", "unknown")
    d.put("properties", properties)
    debug("sending IDENTIFY")
    send(GatewayOp.IDENTIFY, d)
  }

  private fun startHeartbeat(intervalMs: Long) {
    stopHeartbeat()
    debug("heartbeat every ${intervalMs}ms")
    val firstDelay = (intervalMs * Random.nextDouble()).toLong()
    heartbeatJob =
      scope.launch {
        delay(firstDelay)
        if (wsSession != null) {
          sendHeartbeat()
          while (isActive) {
            delay(intervalMs)
            sendHeartbeat()
          }
        }
      }
  }

  private fun sendHeartbeat(force: Boolean = false) {
    if (!force && !lastAck) {
      debug("zombie connection; closing 4009")
      forceClose(4009, "heartbeat ack missed")
      return
    }
    lastAck = false
    lastHeartbeatAt = System.currentTimeMillis()
    val seq = if (liveSeq > 0) liveSeq else null
    send(GatewayOp.HEARTBEAT, seq)
    debug("heartbeat dispatched seq=$seq")
  }

  private fun stopHeartbeat() {
    heartbeatJob?.cancel()
    heartbeatJob = null
  }

  private fun touchSession(
    sessionId: String? = null,
    seq: Int = liveSeq,
    resumeGatewayUrl: String? = null,
  ) {}

  private fun forceClose(
    code: Int,
    reason: String,
  ) {
    scope.launch { wsSession?.close(code, reason) }
  }

  private fun handleClose(
    reason: String,
    code: Int,
  ) {
    if (closed) return
    closed = true
    stopHeartbeat()
    helloTimerJob?.cancel()
    val fatal = NON_RESUMABLE_CLOSE_CODES.contains(code)
    val snapshot = sessionState?.copy(seq = liveSeq)
    if (fatal) sessionState = null
    wsSession = null
    onClose?.invoke(
      GatewayCloseInfo(
        code = code,
        reason = reason,
        resumable = !fatal && snapshot != null,
        session = snapshot,
      ),
    )
    debug("close code=$code reason=$reason resumable=${!fatal && snapshot != null}")
  }

  private fun debug(msg: String) {
    Timber.tag(TAG).v(msg)
    onDebug?.invoke(msg)
  }
}
